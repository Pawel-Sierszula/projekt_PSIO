#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <memory>
#include <math.h>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>


#ifndef BARRIER_H
#define BARRIER_H

//END_BARRIER
class End_barrier: public sf::Sprite, sf::Texture{
public:
//variables
    double pos_x;
    double pos_y;
    double scale=0.1;

public:
//construktor
    End_barrier(sf::Vector2f position){
        setScale(scale,scale);
        setOrigin(130,130);
        pos_x=position.x;
        pos_y=position.y;
        setPosition(position);
    }

    ~End_barrier(){}

//metods
    void move_camera(sf::Vector2f movement){
        move(movement);
        pos_x=getPosition().x;
        pos_y=getPosition().y;
    }

    bool hit(sf::Sprite car){
        bool hit=false;


        double left, right, up, down;
        double Ax, Bx, Cx, Dx;
        double Ay, By, Cy, Dy;
        float angle;
        double high, width;
        double pi=3.14159265359;
        int compare_angle;

        compare_angle=car.getRotation();
        car.setRotation(0);
        sf::FloatRect car_bounds = car.getGlobalBounds();
        high=car_bounds.height;
        width=car_bounds.width;
        car.setRotation(compare_angle);

        car_bounds = car.getGlobalBounds();

        left=car_bounds.left;
        right=car_bounds.left+car_bounds.width;
        up=car_bounds.top;
        down=car_bounds.top+car_bounds.height;
        angle=car.getRotation();

        if(angle>180){angle=angle-180;}
        if(angle<90.0){
            Ay=up;
            Ax=left+(sin(angle*pi/180)*high);

            Cy=down;
            Cx=right-(sin(angle*pi/180)*high);

            By=up+(sin(angle*pi/180)*width);
            Bx=right;

            Dy=down-(sin(angle*pi/180)*width);
            Dx=left;

        }else{
            angle=angle-90.0;

            Ay=up;
            Ax=left+(sin(angle*pi/180)*width);

            Cy=down;
            Cx=right-(sin(angle*pi/180)*width);

            By=up+(sin((angle)*pi/180)*high);
            Bx=right;

            Dy=down-(sin(angle*pi/180)*high);
            Dx=left;
        }

        if((pow(scale*130,2))>(pow(Ax-pos_x,2)+pow(Ay-pos_y,2))){hit=true;}
        if((pow(scale*130,2))>(pow(Bx-pos_x,2)+pow(By-pos_y,2))){hit=true;}
        if((pow(scale*130,2))>(pow(Cx-pos_x,2)+pow(Cy-pos_y,2))){hit=true;}
        if((pow(scale*130,2))>(pow(Dx-pos_x,2)+pow(Dy-pos_y,2))){hit=true;}

        return hit;
    }

};


//MIDDLE_BARRIER_SMALL
class Middle_barrier: public sf::Sprite, sf::Texture{
public:
//variables
    double pos_x;
    double pos_y;

public:
//construktor
    Middle_barrier(sf::Vector2f position){
        setScale(0.1,0.1);
        setOrigin(130,0);
        setPosition(position);
    }

    ~Middle_barrier(){}

//metods
    void move_camera(sf::Vector2f movement){
        move(movement);
    }

    double get_a(double &x1, double &y1, double &x2, double &y2){
        return ((y1-y2)/(x1-x2));
    }
    double get_b(double &x1, double &y1, double &x2, double &y2){
        return (((y1*x2)-(y2*x1))/(x2-x1));
    }
    bool touch_90(double &x, double &y, double &left, double &right, double &up, double &down ){
        bool RET=false;
        if(x<right && x>left && y>up && y<down){
            RET=true;
        }
        return RET;
    }
    bool touch_45(double &x, double &y, double &aAB, double &bAB, double &aBC, double &bBC, double &aCD, double bCD, double &aDA, double &bDA){
        bool RET=false;
        double yAB, yBC, yCD, yDA;

        yAB=(aAB*x)+bAB;
        yBC=(aBC*x)+bBC;
        yCD=(aCD*x)+bCD;
        yDA=(aDA*x)+bDA;

        if(y>yAB){if(y>yDA){if(y<yBC){if(y<yCD){RET=true;}}}}

        return RET;
    }
    bool hit(sf::Sprite car){
        bool hit=false;

        double left[3], right[3], up[3], down[3];
        double Ax[3], Bx[3], Cx[3], Dx[3];
        double Ay[3], By[3], Cy[3], Dy[3];
        double a[3][5], b[3][5];
        float angle[3];
        double high[3], width[3];
        double pi=3.14159265359;
        int compare_angle;
        //double compare_angle1;

        compare_angle=car.getRotation();
        car.setRotation(0);
        sf::FloatRect object1_bounds = car.getGlobalBounds();
        high[1]=object1_bounds.height;
        width[1]=object1_bounds.width;
        car.setRotation(compare_angle);

        compare_angle=getRotation();
        setRotation(0);
        sf::FloatRect object2_bounds = getGlobalBounds();
        high[2]=object2_bounds.height;
        width[2]=object2_bounds.width;
        setRotation(compare_angle);

        object1_bounds = car.getGlobalBounds();
        object2_bounds = getGlobalBounds();

        left[1]=object1_bounds.left;
        right[1]=object1_bounds.left+object1_bounds.width;
        up[1]=object1_bounds.top;
        down[1]=object1_bounds.top+object1_bounds.height;
        angle[1]=car.getRotation();

        left[2]=object2_bounds.left;
        right[2]=object2_bounds.left+object2_bounds.width;
        up[2]=object2_bounds.top;
        down[2]=object2_bounds.top+object2_bounds.height;
        angle[2]=getRotation();



        for(int i=1; i<3; i++){
            //std::cout<<i<<" ";
            if(angle[i]>180){angle[i]=angle[i]-180;}
            if(angle[i]<90.0){
                Ay[i]=up[i];
                Ax[i]=left[i]+(sin(angle[i]*pi/180)*high[i]);

                Cy[i]=down[i];
                Cx[i]=right[i]-(sin(angle[i]*pi/180)*high[i]);

                By[i]=up[i]+(sin(angle[i]*pi/180)*width[i]);
                Bx[i]=right[i];

                Dy[i]=down[i]-(sin(angle[i]*pi/180)*width[i]);
                Dx[i]=left[i];
                //std::cout<<"A("<<Ax[i]<<","<<Ay[i]<<") B("<<Bx[i]<<","<<By[i]<<") C("<<Cx[i]<<","<<Cy[i]<<") D("<<Dx[i]<<","<<Dy[i]<<")"<<std::endl;
            }else{
                angle[i]=angle[i]-90.0;

                Ay[i]=up[i];
                Ax[i]=left[i]+(sin(angle[i]*pi/180)*width[i]);

                Cy[i]=down[i];
                Cx[i]=right[i]-(sin(angle[i]*pi/180)*width[i]);

                By[i]=up[i]+(sin((angle[i])*pi/180)*high[i]);
                Bx[i]=right[i];

                Dy[i]=down[i]-(sin(angle[i]*pi/180)*high[i]);
                Dx[i]=left[i];
                //std::cout<<"A("<<Ax[i]<<","<<Ay[i]<<") B("<<Bx[i]<<","<<By[i]<<") C("<<Cx[i]<<","<<Cy[i]<<") D("<<Dx[i]<<","<<Dy[i]<<")"<<std::endl;
            }

            a[i][1]=get_a(Ax[i],Ay[i],Bx[i],By[i]);
            a[i][2]=get_a(Bx[i],By[i],Cx[i],Cy[i]);
            a[i][3]=get_a(Cx[i],Cy[i],Dx[i],Dy[i]);
            a[i][4]=get_a(Dx[i],Dy[i],Ax[i],Ay[i]);
            b[i][1]=get_b(Ax[i],Ay[i],Bx[i],By[i]);
            b[i][2]=get_b(Bx[i],By[i],Cx[i],Cy[i]);
            b[i][3]=get_b(Cx[i],Cy[i],Dx[i],Dy[i]);
            b[i][4]=get_b(Dx[i],Dy[i],Ax[i],Ay[i]);

            //std::cout<<"a_AB "<<a[i][1]<<" "<<"a_BC "<<a[i][2]<<" "<<"a_CD "<<a[i][3]<<" "<<"a_DA "<<a[i][4]<<std::endl;
            //std::cout<<"b_AB "<<b[i][1]<<" "<<"b_BC "<<b[i][2]<<" "<<"b_CD "<<b[i][3]<<" "<<"b_DA "<<b[i][4]<<std::endl<<std::endl;
        }

        compare_angle=angle[1];
        //std::cout<<compare_angle<<" \n";
        if((compare_angle%90)==0){
            if(touch_90(Ax[2],Ay[2],left[1],right[1],up[1],down[1])==true ||
               touch_90(Bx[2],By[2],left[1],right[1],up[1],down[1])==true ||
               touch_90(Cx[2],Cy[2],left[1],right[1],up[1],down[1])==true ||
               touch_90(Dx[2],Dy[2],left[1],right[1],up[1],down[1])==true ){
                hit=true;
            }
        }else{
            if(touch_45(Ax[2],Ay[2],a[1][1],b[1][1],a[1][2],b[1][2],a[1][3],b[1][3],a[1][4],b[1][4])==true ||
               touch_45(Bx[2],By[2],a[1][1],b[1][1],a[1][2],b[1][2],a[1][3],b[1][3],a[1][4],b[1][4])==true ||
               touch_45(Cx[2],Cy[2],a[1][1],b[1][1],a[1][2],b[1][2],a[1][3],b[1][3],a[1][4],b[1][4])==true ||
               touch_45(Dx[2],Dy[2],a[1][1],b[1][1],a[1][2],b[1][2],a[1][3],b[1][3],a[1][4],b[1][4])==true ){
                hit=true;
            }
        }

        compare_angle=angle[2];
        //std::cout<<compare_angle<<" \n";
        if((compare_angle%90)==0){
            if(touch_90(Ax[1],Ay[1],left[2],right[2],up[2],down[2])==true ||
               touch_90(Bx[1],By[1],left[2],right[2],up[2],down[2])==true ||
               touch_90(Cx[1],Cy[1],left[2],right[2],up[2],down[2])==true ||
               touch_90(Dx[1],Dy[1],left[2],right[2],up[2],down[2])==true ){
                hit=true;
            }
        }else{
            if(touch_45(Ax[1],Ay[1],a[2][1],b[2][1],a[2][2],b[2][2],a[2][3],b[2][3],a[2][4],b[2][4])==true ||
               touch_45(Bx[1],By[1],a[2][1],b[2][1],a[2][2],b[2][2],a[2][3],b[2][3],a[2][4],b[2][4])==true ||
               touch_45(Cx[1],Cy[1],a[2][1],b[2][1],a[2][2],b[2][2],a[2][3],b[2][3],a[2][4],b[2][4])==true ||
               touch_45(Dx[1],Dy[1],a[2][1],b[2][1],a[2][2],b[2][2],a[2][3],b[2][3],a[2][4],b[2][4])==true ){
                hit=true;
            }

        }

        //std::cout<<std::endl;
        return hit;
    }


};
#endif // BARRIER_H
