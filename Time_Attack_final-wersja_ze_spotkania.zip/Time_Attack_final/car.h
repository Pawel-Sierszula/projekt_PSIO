#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <memory>
#include <math.h>
#include <algorithm>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>

#ifndef CAR_H
#define CAR_H

class Car: public sf::Sprite, sf::Texture{
private:
//variables
    //informations
    float speed_scale;
    float braking_scale;
    float speed_decrease;
    float friction_scale;
    float wheels_geo;
    float throtle_scale;
    float engine_braking_scale;


    //imput
    bool gas_pedal=false;
    bool brake_pedal=false;
    bool left_steering=false;
    bool right_steering=false;
    bool engine_status=false;

    //mechanics
    int   gear=0, last_gear=0, check_engine_gear=1;
    float acceleration=0;
    float speed=0;
    float accxtime=0;
    float last_rpm_volume=0;
    float turning_angle;
    float brakes_heat=0;
    float FL_heat=0;
    float FR_heat=0;
    float RL_heat=0;
    float RR_heat=0;


    bool FL_off=false;
    bool FR_off=false;
    bool RL_off=false;
    bool RR_off=false;

    //failures
    bool check_engine=false;

public:    
//construktor

    Car(sf::Vector2f position){
        setScale(0.1, 0.1);
        //setOrigin(412,792.5);
        setOrigin(412,1060);
        setPosition(position);
    }

    ~Car(){}

//metods

    //steering_inputs
    void gas_pressed   (bool up)     {gas_pedal=up;}
    void brake_pressed (bool down)   {brake_pedal=down;}
    void left_pressed  (bool left)   {left_steering=left;}
    void right_pressed (bool right)  {right_steering=right;}
    void engine_switch (bool on_off) {engine_status=on_off;}

    //information_inputs_and_outputs
    void set_speed_scale(float &scale){speed_scale=scale;}
    void set_braking_scale(float &scale){braking_scale=scale;}
    void set_speed_decrease(float &scale){speed_decrease=scale;}
    void set_friction_scale(float &scale){friction_scale=scale;}
    void set_wheels_geometry(float &scale){wheels_geo=scale;}
    void set_throtle_scale(float &scale){throtle_scale=scale;}
    void set_engine_braking_scale(float &scale){engine_braking_scale=scale;}

    void car_size(double &high, double &width ){
        high=1585;
        width=824;
    }

    //collision_reset
    void reverse_rotate(){
        if(speed>0){
            if(gear<0 || last_gear<0){
                if(left_steering){
                    if(right_steering){rotate(0);}else{rotate(-turning_angle);}
                }else{
                    if(right_steering){rotate(turning_angle);}
                }
            }else{
                if(left_steering){
                    if(right_steering){rotate(0);}else{rotate(turning_angle);}
                }else{
                    if(right_steering){rotate(-turning_angle);}
                }
            }

        }
    }
    void reset_speed(){speed=0;}

    //gearbox
    void gearbox(int shift){

        if(gear<5 && shift>0 && !(speed>0 && last_gear==-1)){
            last_gear=gear;
            gear=gear+shift;
        }
        if(gear>-1 && shift<0 && !(speed>0 && last_gear==1 && gear!=2)){
            last_gear=gear;
            gear=gear+shift;
        }

        //std::cout<<gear<<std::endl;
        //if(gear==0){
        //    acceleration=0;
        //}else{
        //    acceleration=0.00001;
        //}

    }
    int  get_gear(){return gear;}
    float gear1(float &x){
        float RET;
        if(x<0.99){
            RET=log10(x+0.01)+2;
        }else{
            RET=2;
        }
        return RET;
    }
    float gear2(float &x){
        float RET;
        if(x<6){
            RET=pow((x/6),2)*2;
        }else{
            if(x<6.99){
                RET=log10(x-6+0.01)+4;
            }else{
                RET=4;
            }
        }
        return RET;
    }
    float gear3(float &x){
        float RET;
        if(x<12){
            RET=pow((x/12),2)*4;
        }else{
            if(x<12.99){
                RET=log10(x-12+0.01)+6;
            }else{
                RET=6;
            }
        }
        return RET;
    }
    float gear4(float &x){
        float RET;
        if(x<24){
            RET=pow((x/24),2)*6;
        }else{
            if(x<24.99){
                RET=log10(x-24+0.01)+8;
            }else{
                RET=8;
            }
        }
        return RET;
    }
    float gear5(float &x){
        float RET;
        if(x<48){
            RET=pow((x/48),2)*8;
        }else{
            if(x<48.99){
                RET=log10(x-48+0.01)+10;
            }else{
                RET=10;
            }
        }
        return RET;
    }
    bool safe_downshift(){
        bool safe_shift=false;
        switch(gear){

            //case 1:{
            //    safe_shift=true;
            //    break;
            //}

            case 2:{
                if((speed*speed_scale)<2){safe_shift=true;}
                break;
            }

            case 3:{
                if((speed*speed_scale)<4){safe_shift=true;}
                break;
            }

            case 4:{
                if((speed*speed_scale)<6){safe_shift=true;}
                break;
            }

            case 5:{
                if((speed*speed_scale)<8){safe_shift=true;}
                break;
            }
        }

        return safe_shift;
    }

    //engine
    void engine(float throtle,float engine_breaking){

        bool found=false;

        speed=speed*speed_scale;
        //if(speed<0){speed=0;}
        acceleration=1;

        //speed_to_accxtime
        if(!check_engine){
            switch(gear){
                case -1:{
                    for(float i=0; i<=50; i=i+1){
                         if(gear1(i)>=speed && found==false){
                             for(float j=i-1; j<=i; j=j+0.0001){
                                 if(gear1(j)>=speed && found==false){
                                     accxtime=j;
                                     found=true;
                                 }
                             }
                         }
                    }
                    if(found==false && engine_status){check_engine=true;}
                    break;
                }

                case 0:{
                    for(float i=0; i<=50; i=i+1){
                         if(gear1(i)>=speed && found==false){
                             for(float j=i-1; j<=i; j=j+0.0001){
                                 if(gear1(j)>=speed && found==false){
                                     found=true;
                                 }
                             }
                         }
                    }
                    acceleration=0;
                    break;
                }

                case 1:{
                    for(float i=0; i<=50; i=i+1){
                         if(gear1(i)>=speed && found==false){
                             for(float j=i-1; j<=i; j=j+0.0001){
                                 if(gear1(j)>=speed && found==false){
                                     accxtime=j;
                                     found=true;
                                 }
                             }
                         }
                    }
                    if(found==false && engine_status){check_engine=true;}
                    //std::cout<<"gear="<<gear<<" acc="<<accxtime<<" speed="<<speed<<std::endl;
                    break;
                }

                case 2:{
                    for(float i=0; i<=50; i=i+1){
                         if(gear2(i)>=speed && found==false){
                             for(float j=i-1; j<=i; j=j+0.0001){
                                 if(gear2(j)>=speed && found==false){
                                     accxtime=j;
                                     found=true;
                                 }
                             }
                         }
                    }
                    if(found==false && engine_status){check_engine=true;}
                    //std::cout<<"gear="<<gear<<" acc="<<accxtime<<" speed="<<speed<<std::endl;
                    break;
                }

                case 3:{
                    for(float i=0; i<=50; i=i+1){
                         if(gear3(i)>=speed && found==false){
                             for(float j=i-1; j<=i; j=j+0.0001){
                                 if(gear3(j)>=speed && found==false){
                                     accxtime=j;
                                     found=true;
                                 }
                             }
                         }
                    }
                    if(found==false && engine_status){check_engine=true;}
                    //std::cout<<"gear="<<gear<<" acc="<<accxtime<<" speed="<<speed<<std::endl;
                    break;
                }

                case 4:{
                    for(float i=0; i<=50; i=i+1){
                         if(gear4(i)>=speed && found==false){
                             for(float j=i-1; j<=i; j=j+0.0001){
                                 if(gear4(j)>=speed && found==false){
                                     accxtime=j;
                                     found=true;
                                 }
                             }
                         }
                    }
                    if(found==false && engine_status){check_engine=true;}
                    //std::cout<<"gear="<<gear<<" acc="<<accxtime<<" speed="<<speed<<std::endl;
                    break;
                }

                case 5:{
                    for(float i=0; i<=50; i=i+1){
                         if(gear5(i)>=speed && found==false){
                             for(float j=i-1; j<=i; j=j+0.0001){
                                 if(gear5(j)>=speed && found==false){
                                     accxtime=j;
                                     found=true;
                                 }
                             }
                         }
                    }
                    //std::cout<<"gear="<<gear<<" acc="<<accxtime<<" speed="<<speed<<std::endl;
                    break;
                }
            }
            if(check_engine){
                check_engine_gear=gear;
                speed=speed/2;
            }
        }

        //acceleration
        if(gas_pedal && !check_engine && engine_status){
            accxtime=accxtime+throtle;
        }

        //engine_breaking
        if(!gas_pedal && !check_engine && !brake_pedal && engine_status){
            //std::cout<<"engine_breaking"<<std::endl;
            if(!brake_pedal){
                switch(gear){
                    case -1:{
                        if(accxtime<0.006){
                            accxtime=accxtime+engine_breaking;
                        }else{
                            accxtime=accxtime-engine_breaking;
                        }
                        break;
                    }

                    case 1:{
                        if(accxtime<0.006){
                            accxtime=accxtime+engine_breaking;
                        }else{
                            accxtime=accxtime-engine_breaking;
                        }
                        //std::cout<<"gear="<<gear<<" acc="<<accxtime<<" speed="<<speed<<std::endl;
                        break;
                    }

                    case 2:{
                        if(accxtime<2.684){
                            accxtime=accxtime+engine_breaking;
                        }else{
                            accxtime=accxtime-engine_breaking;
                        }
                        //std::cout<<"gear="<<gear<<" acc="<<accxtime<<" speed="<<speed<<std::endl;
                        break;
                    }

                    case 3:{
                        if(accxtime<4.648){
                            accxtime=accxtime+engine_breaking;
                        }else{
                            accxtime=accxtime-engine_breaking;
                        }
                        //std::cout<<"gear="<<gear<<" acc="<<accxtime<<" speed="<<speed<<std::endl;
                        break;
                    }

                    case 4:{
                        if(accxtime<8.764){
                            accxtime=accxtime+engine_breaking;
                        }else{
                            accxtime=accxtime-engine_breaking;
                        }
                        //std::cout<<"gear="<<gear<<" acc="<<accxtime<<" speed="<<speed<<std::endl;
                        break;
                    }

                    case 5:{
                        if(accxtime<16.971){
                            accxtime=accxtime+engine_breaking;
                        }else{
                            accxtime=accxtime-engine_breaking;
                        }
                        //std::cout<<"gear="<<gear<<" acc="<<accxtime<<" speed="<<speed<<std::endl;
                        break;
                    }
                }
            }
        }

        //accxtime_to_speed
        if(!check_engine && !brake_pedal && engine_status){
            switch(gear){
                case -1:{
                    speed=gear1(accxtime);
                    break;
                }

                case 0:{
                    acceleration=0;
                    break;
                }

                case 1:{
                    speed=gear1(accxtime);
                    //std::cout<<"gear="<<gear<<" acc="<<accxtime<<" speed="<<speed<<std::endl;
                    break;
                }

                case 2:{
                    speed=gear2(accxtime);
                    //std::cout<<"gear="<<gear<<" acc="<<accxtime<<" speed="<<speed<<std::endl;
                    break;
                }

                case 3:{
                    speed=gear3(accxtime);
                    //std::cout<<"gear="<<gear<<" acc="<<accxtime<<" speed="<<speed<<std::endl;
                    break;
                }

                case 4:{
                    speed=gear4(accxtime);
                    //std::cout<<"gear="<<gear<<" acc="<<accxtime<<" speed="<<speed<<std::endl;
                    break;
                }

                case 5:{
                    speed=gear5(accxtime);
                    //std::cout<<"gear="<<gear<<" acc="<<accxtime<<" speed="<<speed<<std::endl;
                    break;
                }
            }
        }

        //if(speed<0){speed=0;}

        speed=speed/speed_scale;

    }    
    bool check_engine_status(){return check_engine;}
    bool engine_on_off_status(){return engine_status;}
    float engine_rpm(float max_rpm){
        float rpm_volume;

        switch(gear){
            case -1:{
                if((speed*speed_scale)<0.2 && brake_pedal){
                    rpm_volume=(max_rpm*0.2)/2;
                }else{
                    rpm_volume=(max_rpm*speed*speed_scale)/2;
                }
                break;
            }

            case 0:{
                if(gas_pedal){
                    if(last_rpm_volume<max_rpm){
                        rpm_volume=last_rpm_volume+1;
                    }else{
                        rpm_volume=max_rpm;
                    }
                }else{
                    if(last_rpm_volume<(max_rpm/10)){
                        rpm_volume=last_rpm_volume+0.5;
                    }else{
                        rpm_volume=last_rpm_volume-1;
                    }
                }
                break;
            }

            case 1:{
                if((speed*speed_scale)<0.2 && brake_pedal){
                    rpm_volume=(max_rpm*0.2)/2;
                }else{
                    rpm_volume=(max_rpm*speed*speed_scale)/2;
                }
                break;
            }

            case 2:{
                if((speed*speed_scale)<0.4 && brake_pedal){
                    rpm_volume=(max_rpm*0.4)/4;
                }else{
                    rpm_volume=(max_rpm*speed*speed_scale)/4;
                }
                break;
            }

            case 3:{
                if((speed*speed_scale)<0.6 && brake_pedal){
                    rpm_volume=(max_rpm*0.6)/6;
                }else{
                    rpm_volume=(max_rpm*speed*speed_scale)/6;
                }
                break;
            }

            case 4:{
                if((speed*speed_scale)<0.8 && brake_pedal){
                    rpm_volume=(max_rpm*0.8)/8;
                }else{
                    rpm_volume=(max_rpm*speed*speed_scale)/8;
                }
                break;
            }

            case 5:{
                if((speed*speed_scale)<1 && brake_pedal){
                    rpm_volume=max_rpm/10;
                }else{
                    rpm_volume=(max_rpm*speed*speed_scale)/10;
                }
                break;
            }
        }

        if(check_engine || !engine_status){rpm_volume=0;}
        last_rpm_volume=rpm_volume;

        return rpm_volume;
    }

    //speedometer
    int speed_unity(){
        int speed_rounded=speed*speed_scale*20;
        speed_rounded=speed_rounded%10;
        return speed_rounded;
    }
    int speed_dozens(){
        int speed_rounded=speed*speed_scale*20;
        speed_rounded=(speed_rounded/10)%10;
        return speed_rounded;
    }
    int speed_hundreds(){
        int speed_rounded=speed*speed_scale*20;
        speed_rounded=speed_rounded/100;
        return speed_rounded;
    }

    void pitlane_speed(bool pitlane){
        if(pitlane){
            if(speed*speed_scale>2.5){speed=2.5/speed_scale;}
        }
    }

    //breaks
    void breaking(){
        if(brake_pedal && speed>0){
            if(brakes_heat<10 ){brakes_heat=brakes_heat+(0.00005*speed*speed_scale*braking_scale);}
            if(brakes_heat>1 && brakes_heat<7){
                if(speed>0){speed=speed-(0.0001*braking_scale);}
            }else{
                if(speed>0){speed=speed-(0.00002*braking_scale);}
            }
        }else{
            if(brakes_heat>0){brakes_heat=brakes_heat-(0.00002*braking_scale);}
        }
        if(brakes_heat<0){brakes_heat=0;}
        if(brakes_heat>10){brakes_heat=10;}
        if(speed<0){speed=0;}
    }
    float get_brakes_heat(){return brakes_heat;}
    void  set_brakes_heat(float &heat){brakes_heat=heat;}

    //tires
    void is_FL_off(bool status){FL_off=status;}
    void is_FR_off(bool status){FR_off=status;}
    void is_RL_off(bool status){RL_off=status;}
    void is_RR_off(bool status){RR_off=status;}
    void one_wheel_heat_balance(float &Wheel_heat, bool &Wheel_off){
        if(Wheel_off && speed>0){
            if(Wheel_heat<10){Wheel_heat=Wheel_heat+(0.0001*speed*speed_scale*friction_scale);}
        }
        if(left_steering||right_steering){
            if(Wheel_heat<10){Wheel_heat=Wheel_heat+(0.00005*speed*speed_scale*friction_scale);}
        }
        if(!(Wheel_off && speed>0) && !left_steering && !right_steering){
            if(Wheel_heat>0){Wheel_heat=Wheel_heat-(0.000075*(11-(speed*speed_scale))*friction_scale);}
        }
        if(Wheel_heat<0){Wheel_heat=0;}
        if(Wheel_heat>10){Wheel_heat=10;}
    }
    void wheels_heat_balance(){
        one_wheel_heat_balance(FL_heat,FL_off);
        one_wheel_heat_balance(FR_heat,FR_off);
        one_wheel_heat_balance(RL_heat,RL_off);
        one_wheel_heat_balance(RR_heat,RR_off);
    }
    float get_FL_heat(){return FL_heat;}
    float get_FR_heat(){return FR_heat;}
    float get_RL_heat(){return RL_heat;}
    float get_RR_heat(){return RR_heat;}

    //steering_system
    void steeting_system(){
        //paramets
        float speed_influence=1/(speed*speed_scale/4);
        if(speed_influence>1){speed_influence=1;}
        if(speed*speed_scale<2){speed_influence=speed_influence*speed*speed_scale/2;}
        if(FL_heat<1 || FL_heat>7){
            if(left_steering){speed_influence=speed_influence/2;}
        }
        if(FR_heat<1 || FR_heat>7){
            if(right_steering){speed_influence=speed_influence/2;}
        }

        //steering
        turning_angle=wheels_geo*speed_influence;
        if(speed>0){
            if(gear<0 || last_gear<0){
                if(left_steering){
                    if(right_steering){rotate(0);}else{rotate(turning_angle);}
                }else{
                    if(right_steering){rotate(-turning_angle);}
                }
            }else{
                if(left_steering){
                    if(right_steering){rotate(0);}else{rotate(-turning_angle);}
                }else{
                    if(right_steering){rotate(turning_angle);}
                }
            }

        }
    }

    //car_movement
    void speed_lose(){
        speed=speed*speed_scale;
        if(!check_engine){
            if((!gas_pedal && !brake_pedal) || gear==0){
                speed=speed-speed_decrease;
            }
        }else{
             speed=speed-(2*speed_decrease*abs(check_engine_gear));
        }
        if(FL_off||FR_off||RL_off||RR_off){
            if(speed*speed_scale>0.1){speed=speed-(speed*(speed_scale/2)*speed_decrease/2);}
        }
        if(speed<0){speed=0;}
        speed=speed/speed_scale;
    }
    int get_speed(){return (speed*speed_scale/1);}
    sf::Vector2f car_movement(){
        float angle, rad, pi=3.14159265359, x=0, y=0;

        engine(throtle_scale,engine_braking_scale);
        speed_lose();
        breaking();
        steeting_system();
        //std::cout<<speed<<" "<<accxtime<<std::endl;

        angle=0;
        angle=getRotation();
        rad=angle*pi/180;

        y=speed*cos(rad);
        x=speed*(-sin(rad));

        if((gear<0 || last_gear<0) && !check_engine){
            x=-x;
            y=-y;
        }
        if(speed>0){
            return sf::Vector2f(x,y);
        }else{
            if(speed<0){
                return sf::Vector2f(-x,-y);
            }else{
                return sf::Vector2f(0,0);
            }
        }

    }

};

#endif // CAR_H
