#include <iostream>
#include <string>
#include <fstream>
#include <stdlib.h>
#include <time.h>
#include <memory>
#include <math.h>
#include <list>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>

#include "tor.h"
#include "car.h"
#include "hud.h"
#include "barrier.h"


#ifndef FUNCTIONS_H
#define FUNCTIONS_H


//READ_DATA
void create_propertis(){
    std::fstream plik;
    plik.open("propertis.txt",std::ios_base::out);

    std::cout<<"creatng_propertis_file"<<std::endl;

    plik<<"speed_scale: 20"<<std::endl;
    plik<<"braking_scale: 1"<<std::endl;
    plik<<"speed_decrease: 0.0001"<<std::endl;
    plik<<"friction_scale: 1"<<std::endl;
    plik<<"wheels_geometry: 0.05"<<std::endl;
    plik<<"throtle_scale: 0.002"<<std::endl;
    plik<<"engine_braking_scale: 0.001"<<std::endl;

}
void read_data(float &speed_scale,float &braking_scale,float &speed_decrease,float &friction_scale,float &wheels_geometry,float &throtle_scale,float &engine_braking_scale){
    std::fstream plik;
    std::vector<std::string>name;
    std::vector<std::string>value;
    std::string read_name;
    std::string read_value;
    plik.open("propertis.txt",std::ios_base::in);
    while(!plik.good()){
        create_propertis();
        plik.open("propertis.txt",std::ios_base::in);
        std::cout<<"propertis_file_not_found"<<std::endl;
    }
    while(plik>>read_name){
        plik>>read_value;
        name.emplace_back(read_name);
        value.emplace_back(read_value);
    }
    for(size_t i=0; i<name.size(); i++){
        if(name[i]=="speed_scale:"){
            speed_scale=std::stof(value[i]);
            //std::cout<<"speed_scale: "<<speed_scale<<std::endl;
        }

        if(name[i]=="braking_scale:"){
            braking_scale=std::stof(value[i]);
            //std::cout<<"braking_scale: "<<braking_scale<<std::endl;
        }

        if(name[i]=="speed_decrease:"){
            speed_decrease=std::stof(value[i]);
            //std::cout<<"speed_decrease: "<<speed_decrease<<std::endl;
        }

        if(name[i]=="friction_scale:"){
            friction_scale=std::stof(value[i]);
            //std::cout<<"friction_scale: "<<friction_scale<<std::endl;
        }

        if(name[i]=="wheels_geometry:"){
            wheels_geometry=std::stof(value[i]);
            //std::cout<<"wheels_geometry: "<<wheels_geometry<<std::endl;
        }

        if(name[i]=="throtle_scale:"){
            throtle_scale=std::stof(value[i]);
            //std::cout<<"throtle_scale: "<<throtle_scale<<std::endl;
        }

        if(name[i]=="engine_braking_scale:"){
            engine_braking_scale=std::stof(value[i]);
            //std::cout<<"engine_braking_scale: "<<engine_braking_scale<<std::endl;
        }
    }

}

//CREATE_BARRIERS
void create_barriers(std::vector<End_barrier> &end_barrier ,std::vector<Middle_barrier> &mid_barrier, sf::Texture *end_bar_texture_p, sf::Texture *bar_1_texture_p, sf::Texture *bar_6_texture_p){

    //1
    end_barrier.emplace_back(End_barrier(sf::Vector2f (750,-590)));
    end_barrier[0].setTexture(*end_bar_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (750,-590)));
    mid_barrier[0].setTexture(*bar_1_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (750,-575)));
    mid_barrier[1].setTextureRect(sf::IntRect(0, 0, 260, 18900));
    mid_barrier[1].setTexture(*bar_6_texture_p);

    end_barrier.emplace_back(End_barrier(sf::Vector2f (750,1315)));
    end_barrier[1].setTexture(*end_bar_texture_p);
    end_barrier[1].setRotation(180);

    //2
    end_barrier.emplace_back(End_barrier(sf::Vector2f (750,-620)));
    end_barrier[2].setRotation(150);
    end_barrier[2].setTexture(*end_bar_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (750,-620)));
    mid_barrier[2].setRotation(150);
    mid_barrier[2].setTexture(*bar_1_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (742.5,-633)));
    mid_barrier[3].setRotation(150);
    mid_barrier[3].setTextureRect(sf::IntRect(0, 0, 260, 3600));
    mid_barrier[3].setTexture(*bar_6_texture_p);

    end_barrier.emplace_back(End_barrier(sf::Vector2f (562.5,-945)));
    end_barrier[3].setRotation(330);
    end_barrier[3].setTexture(*end_bar_texture_p);

    //3
    end_barrier.emplace_back(End_barrier(sf::Vector2f (542.5,-965)));
    end_barrier[4].setRotation(120);
    end_barrier[4].setTexture(*end_bar_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (542.5,-965)));
    mid_barrier[4].setRotation(120);
    mid_barrier[4].setTexture(*bar_1_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (529.5,-972.5)));
    mid_barrier[5].setRotation(120);
    mid_barrier[5].setTextureRect(sf::IntRect(0, 0, 260, 2700));
    mid_barrier[5].setTexture(*bar_6_texture_p);

    end_barrier.emplace_back(End_barrier(sf::Vector2f (295.5,-1107.5)));
    end_barrier[5].setRotation(300);
    end_barrier[5].setTexture(*end_bar_texture_p);

    //4
    end_barrier.emplace_back(End_barrier(sf::Vector2f (265,-1110)));
    end_barrier[6].setRotation(90);
    end_barrier[6].setTexture(*end_bar_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (265,-1110)));
    mid_barrier[6].setRotation(90);
    mid_barrier[6].setTexture(*bar_1_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (250,-1110)));
    mid_barrier[7].setRotation(90);
    mid_barrier[7].setTextureRect(sf::IntRect(0, 0, 260, 9000));
    mid_barrier[7].setTexture(*bar_6_texture_p);

    end_barrier.emplace_back(End_barrier(sf::Vector2f (-650,-1110)));
    end_barrier[7].setRotation(270);
    end_barrier[7].setTexture(*end_bar_texture_p);

    //5
    end_barrier.emplace_back(End_barrier(sf::Vector2f (800,400)));
    end_barrier[8].setRotation(270);
    end_barrier[8].setTexture(*end_bar_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (800,400)));
    mid_barrier[8].setRotation(270);
    mid_barrier[8].setTexture(*bar_1_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (815,400)));
    mid_barrier[9].setRotation(270);
    mid_barrier[9].setTextureRect(sf::IntRect(0, 0, 260, 7200));
    mid_barrier[9].setTexture(*bar_6_texture_p);

    end_barrier.emplace_back(End_barrier(sf::Vector2f (1535,400)));
    end_barrier[9].setRotation(90);
    end_barrier[9].setTexture(*end_bar_texture_p);

    //6
    end_barrier.emplace_back(End_barrier(sf::Vector2f (1535,430)));
    end_barrier[10].setRotation(0);
    end_barrier[10].setTexture(*end_bar_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (1535,430)));
    mid_barrier[10].setRotation(0);
    mid_barrier[10].setTexture(*bar_1_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (1535,445)));
    mid_barrier[11].setRotation(0);
    mid_barrier[11].setTextureRect(sf::IntRect(0, 0, 260, 1200));
    mid_barrier[11].setTexture(*bar_6_texture_p);

    end_barrier.emplace_back(End_barrier(sf::Vector2f (1535,565)));
    end_barrier[11].setRotation(180);
    end_barrier[11].setTexture(*end_bar_texture_p);

    //7
    end_barrier.emplace_back(End_barrier(sf::Vector2f (1535,595)));
    end_barrier[12].setRotation(45);
    end_barrier[12].setTexture(*end_bar_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (1535,595)));
    mid_barrier[12].setRotation(45);
    mid_barrier[12].setTexture(*bar_1_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (1524.4,605.6)));
    mid_barrier[13].setRotation(45);
    mid_barrier[13].setTextureRect(sf::IntRect(0, 0, 260, 17700));
    mid_barrier[13].setTexture(*bar_6_texture_p);

    end_barrier.emplace_back(End_barrier(sf::Vector2f (272.8,1857)));
    end_barrier[13].setRotation(225);
    end_barrier[13].setTexture(*end_bar_texture_p);

    //8
    end_barrier.emplace_back(End_barrier(sf::Vector2f (240,1857)));
    end_barrier[14].setRotation(135);
    end_barrier[14].setTexture(*end_bar_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (240,1857)));
    mid_barrier[14].setRotation(135);
    mid_barrier[14].setTexture(*bar_1_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (229.4,1846.4)));
    mid_barrier[15].setRotation(135);
    mid_barrier[15].setTextureRect(sf::IntRect(0, 0, 260, 3600));
    mid_barrier[15].setTexture(*bar_6_texture_p);

    end_barrier.emplace_back(End_barrier(sf::Vector2f (-25,1592)));
    end_barrier[15].setRotation(315);
    end_barrier[15].setTexture(*end_bar_texture_p);

    //9
    end_barrier.emplace_back(End_barrier(sf::Vector2f (50,-350)));
    end_barrier[16].setRotation(0);
    end_barrier[16].setTexture(*end_bar_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (50,-350)));
    mid_barrier[16].setRotation(0);
    mid_barrier[16].setTexture(*bar_1_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (50,-335)));
    mid_barrier[17].setRotation(0);
    mid_barrier[17].setTextureRect(sf::IntRect(0, 0, 260, 12600));
    mid_barrier[17].setTexture(*bar_6_texture_p);

    end_barrier.emplace_back(End_barrier(sf::Vector2f (50,925)));
    end_barrier[17].setRotation(180);
    end_barrier[17].setTexture(*end_bar_texture_p);

    //10                                                                <--possible_pit_stop_exit
    end_barrier.emplace_back(End_barrier(sf::Vector2f (-1500,-350)));
    end_barrier[18].setRotation(270);
    end_barrier[18].setTexture(*end_bar_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (-1500,-350)));
    mid_barrier[18].setRotation(270);
    mid_barrier[18].setTexture(*bar_1_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (-1485,-350)));
    mid_barrier[19].setRotation(270);
    mid_barrier[19].setTextureRect(sf::IntRect(0, 0, 260, 12600));
    mid_barrier[19].setTexture(*bar_6_texture_p);

    end_barrier.emplace_back(End_barrier(sf::Vector2f (-225,-350)));
    end_barrier[19].setRotation(90);
    end_barrier[19].setTexture(*end_bar_texture_p);

    //11
    end_barrier.emplace_back(End_barrier(sf::Vector2f (-1500,-380)));
    end_barrier[20].setRotation(180);
    end_barrier[20].setTexture(*end_bar_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (-1500,-380)));
    mid_barrier[20].setRotation(180);
    mid_barrier[20].setTexture(*bar_1_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (-1500,-395)));
    mid_barrier[21].setRotation(180);
    mid_barrier[21].setTextureRect(sf::IntRect(0, 0, 260, 13500));
    mid_barrier[21].setTexture(*bar_6_texture_p);

    end_barrier.emplace_back(End_barrier(sf::Vector2f (-1500,-1745)));
    end_barrier[21].setRotation(0);
    end_barrier[21].setTexture(*end_bar_texture_p);

    //12
    end_barrier.emplace_back(End_barrier(sf::Vector2f (-1500,-1780)));
    end_barrier[22].setRotation(270);
    end_barrier[22].setTexture(*end_bar_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (-1500,-1780)));
    mid_barrier[22].setRotation(270);
    mid_barrier[22].setTexture(*bar_1_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (-1485,-1780)));
    mid_barrier[23].setRotation(270);
    mid_barrier[23].setTextureRect(sf::IntRect(0, 0, 260, 22500));
    mid_barrier[23].setTexture(*bar_6_texture_p);

    end_barrier.emplace_back(End_barrier(sf::Vector2f (765,-1780)));
    end_barrier[23].setRotation(90);
    end_barrier[23].setTexture(*end_bar_texture_p);

    //13
    end_barrier.emplace_back(End_barrier(sf::Vector2f (795,-1750)));
    end_barrier[24].setRotation(315);
    end_barrier[24].setTexture(*end_bar_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (795,-1750)));
    mid_barrier[24].setRotation(315);
    mid_barrier[24].setTexture(*bar_1_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (805.6,-1739.4)));
    mid_barrier[25].setRotation(315);
    mid_barrier[25].setTextureRect(sf::IntRect(0, 0, 260, 20100));
    mid_barrier[25].setTexture(*bar_6_texture_p);

    end_barrier.emplace_back(End_barrier(sf::Vector2f (2226.9,-318.1)));
    end_barrier[25].setRotation(135);
    end_barrier[25].setTexture(*end_bar_texture_p);

    //14
    end_barrier.emplace_back(End_barrier(sf::Vector2f (2227,-290)));
    end_barrier[26].setRotation(0);
    end_barrier[26].setTexture(*end_bar_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (2227,-290)));
    mid_barrier[26].setRotation(0);
    mid_barrier[26].setTexture(*bar_1_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (2227,-275)));
    mid_barrier[27].setRotation(0);
    mid_barrier[27].setTextureRect(sf::IntRect(0, 0, 260, 11400));
    mid_barrier[27].setTexture(*bar_6_texture_p);

    end_barrier.emplace_back(End_barrier(sf::Vector2f (2227,865)));
    end_barrier[27].setRotation(180);
    end_barrier[27].setTexture(*end_bar_texture_p);

    //15
    end_barrier.emplace_back(End_barrier(sf::Vector2f (2207,885)));
    end_barrier[28].setRotation(45);
    end_barrier[28].setTexture(*end_bar_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (2207,885)));
    mid_barrier[28].setRotation(45);
    mid_barrier[28].setTexture(*bar_1_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (2196.4,895.6)));
    mid_barrier[29].setRotation(45);
    mid_barrier[29].setTextureRect(sf::IntRect(0, 0, 260, 27000));
    mid_barrier[29].setTexture(*bar_6_texture_p);

    end_barrier.emplace_back(End_barrier(sf::Vector2f (287.2,2804.8)));
    end_barrier[29].setRotation(225);
    end_barrier[29].setTexture(*end_bar_texture_p);

    //16
    end_barrier.emplace_back(End_barrier(sf::Vector2f (257,2805)));
    end_barrier[30].setRotation(90);
    end_barrier[30].setTexture(*end_bar_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (257,2805)));
    mid_barrier[30].setRotation(90);
    mid_barrier[30].setTexture(*bar_1_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (242,2805)));
    mid_barrier[31].setRotation(90);
    mid_barrier[31].setTextureRect(sf::IntRect(0, 0, 260, 2700));
    mid_barrier[31].setTexture(*bar_6_texture_p);

    end_barrier.emplace_back(End_barrier(sf::Vector2f (-28,2805)));
    end_barrier[31].setRotation(270);
    end_barrier[31].setTexture(*end_bar_texture_p);

    //17
    end_barrier.emplace_back(End_barrier(sf::Vector2f (-58,2805)));
    end_barrier[32].setRotation(135);
    end_barrier[32].setTexture(*end_bar_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (-58,2805)));
    mid_barrier[32].setRotation(135);
    mid_barrier[32].setTexture(*bar_1_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (-68.6,2794.4)));
    mid_barrier[33].setRotation(135);
    mid_barrier[33].setTextureRect(sf::IntRect(0, 0, 260, 5400));
    mid_barrier[33].setTexture(*bar_6_texture_p);

    end_barrier.emplace_back(End_barrier(sf::Vector2f (-450,2412.6)));
    end_barrier[33].setRotation(315);
    end_barrier[33].setTexture(*end_bar_texture_p);

    //18
    end_barrier.emplace_back(End_barrier(sf::Vector2f (-450,2385)));
    end_barrier[34].setRotation(180);
    end_barrier[34].setTexture(*end_bar_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (-450,2385)));
    mid_barrier[34].setRotation(180);
    mid_barrier[34].setTexture(*bar_1_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (-450,2370)));
    mid_barrier[35].setRotation(180);
    mid_barrier[35].setTextureRect(sf::IntRect(0, 0, 260, 900));
    mid_barrier[35].setTexture(*bar_6_texture_p);

    end_barrier.emplace_back(End_barrier(sf::Vector2f (-450,2280)));
    end_barrier[35].setRotation(0);
    end_barrier[35].setTexture(*end_bar_texture_p);

    //19
    end_barrier.emplace_back(End_barrier(sf::Vector2f (-470,2260)));
    end_barrier[36].setRotation(135);
    end_barrier[36].setTexture(*end_bar_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (-470,2260)));
    mid_barrier[36].setRotation(135);
    mid_barrier[36].setTexture(*bar_1_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (-480.6,2249.4)));
    mid_barrier[37].setRotation(135);
    mid_barrier[37].setTextureRect(sf::IntRect(0, 0, 260, 7200));
    mid_barrier[37].setTexture(*bar_6_texture_p);

    end_barrier.emplace_back(End_barrier(sf::Vector2f (-989.7,1740.3)));
    end_barrier[37].setRotation(315);
    end_barrier[37].setTexture(*end_bar_texture_p);

    //20
    end_barrier.emplace_back(End_barrier(sf::Vector2f (-990,1710)));
    end_barrier[38].setRotation(180);
    end_barrier[38].setTexture(*end_bar_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (-990,1710)));
    mid_barrier[38].setRotation(180);
    mid_barrier[38].setTexture(*bar_1_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (-990,1695)));
    mid_barrier[39].setRotation(180);
    mid_barrier[39].setTextureRect(sf::IntRect(0, 0, 260, 7460));
    mid_barrier[39].setTexture(*bar_6_texture_p);

    end_barrier.emplace_back(End_barrier(sf::Vector2f (-990,950)));
    end_barrier[39].setRotation(0);
    end_barrier[39].setTexture(*end_bar_texture_p);

    //21
    end_barrier.emplace_back(End_barrier(sf::Vector2f (-960,950)));
    end_barrier[40].setRotation(270);
    end_barrier[40].setTexture(*end_bar_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (-960,950)));
    mid_barrier[40].setRotation(270);
    mid_barrier[40].setTexture(*bar_1_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (-945,950)));
    mid_barrier[41].setRotation(270);
    mid_barrier[41].setTextureRect(sf::IntRect(0, 0, 260, 7500));
    mid_barrier[41].setTexture(*bar_6_texture_p);

    end_barrier.emplace_back(End_barrier(sf::Vector2f (-195,950)));
    end_barrier[41].setRotation(90);
    end_barrier[41].setTexture(*end_bar_texture_p);
}


//CREATE_NUMBERS
void create_numbers(std::vector<Numbers> &numbers, sf::Texture *numbers_texture_p){

 //speedometer

   //hundreds
   numbers.emplace_back(Numbers(sf::Vector2f(335,530)));
   numbers[0].setTexture(*numbers_texture_p);
   numbers[0].setScale(0.05,0.05);
   numbers[0].set_number(-1);

   //dozens
   numbers.emplace_back(Numbers(sf::Vector2f(355,530)));
   numbers[1].setTexture(*numbers_texture_p);
   numbers[1].setScale(0.05,0.05);
   numbers[1].set_number(-1);

   //unity
   numbers.emplace_back(Numbers(sf::Vector2f(375,530)));
   numbers[2].setTexture(*numbers_texture_p);
   numbers[2].setScale(0.05,0.05);
   numbers[2].set_number(0);


//current_time
   //C_DozensMinutes
   numbers.emplace_back(Numbers(sf::Vector2f(115,5)));
   numbers[3].setTexture(*numbers_texture_p);
   numbers[3].set_number(0);

   //C_UnityMinutes
   numbers.emplace_back(Numbers(sf::Vector2f(130,5)));
   numbers[4].setTexture(*numbers_texture_p);
   numbers[4].set_number(0);

   //C_DozensSeconds
   numbers.emplace_back(Numbers(sf::Vector2f(150,5)));
   numbers[5].setTexture(*numbers_texture_p);
   numbers[5].set_number(0);

   //C_UnitySeconds
   numbers.emplace_back(Numbers(sf::Vector2f(165,5)));
   numbers[6].setTexture(*numbers_texture_p);
   numbers[6].set_number(0);

   //C_decimal
   numbers.emplace_back(Numbers(sf::Vector2f(185,5)));
   numbers[7].setTexture(*numbers_texture_p);
   numbers[7].set_number(0);


   //C_hundredths
   numbers.emplace_back(Numbers(sf::Vector2f(200,5)));
   numbers[8].setTexture(*numbers_texture_p);
   numbers[8].set_number(0);

   //C_thousand
   numbers.emplace_back(Numbers(sf::Vector2f(215,5)));
   numbers[9].setTexture(*numbers_texture_p);
   numbers[9].set_number(0);


//last_time
   //L_DozensMinutes
   numbers.emplace_back(Numbers(sf::Vector2f(115,35)));
   numbers[10].setTexture(*numbers_texture_p);
   numbers[10].set_number(-2);

   //L_UnityMinutes
   numbers.emplace_back(Numbers(sf::Vector2f(130,35)));
   numbers[11].setTexture(*numbers_texture_p);
   numbers[11].set_number(-2);

   //L_DozensSeconds
   numbers.emplace_back(Numbers(sf::Vector2f(150,35)));
   numbers[12].setTexture(*numbers_texture_p);
   numbers[12].set_number(-2);

   //L_UnitySeconds
   numbers.emplace_back(Numbers(sf::Vector2f(165,35)));
   numbers[13].setTexture(*numbers_texture_p);
   numbers[13].set_number(-2);

   //L_decimal
   numbers.emplace_back(Numbers(sf::Vector2f(185,35)));
   numbers[14].setTexture(*numbers_texture_p);
   numbers[14].set_number(-2);


   //L_hundredths
   numbers.emplace_back(Numbers(sf::Vector2f(200,35)));
   numbers[15].setTexture(*numbers_texture_p);
   numbers[15].set_number(-2);

   //L_thousand
   numbers.emplace_back(Numbers(sf::Vector2f(215,35)));
   numbers[16].setTexture(*numbers_texture_p);
   numbers[16].set_number(-2);

//best_time
   //B_DozensMinutes
   numbers.emplace_back(Numbers(sf::Vector2f(115,65)));
   numbers[17].setTexture(*numbers_texture_p);
   numbers[17].set_number(-2);

   //B_UnityMinutes
   numbers.emplace_back(Numbers(sf::Vector2f(130,65)));
   numbers[18].setTexture(*numbers_texture_p);
   numbers[18].set_number(-2);

   //B_DozensSeconds
   numbers.emplace_back(Numbers(sf::Vector2f(150,65)));
   numbers[19].setTexture(*numbers_texture_p);
   numbers[19].set_number(-2);

   //B_UnitySeconds
   numbers.emplace_back(Numbers(sf::Vector2f(165,65)));
   numbers[20].setTexture(*numbers_texture_p);
   numbers[20].set_number(-2);

   //B_decimal
   numbers.emplace_back(Numbers(sf::Vector2f(185,65)));
   numbers[21].setTexture(*numbers_texture_p);
   numbers[21].set_number(-2);


   //B_hundredths
   numbers.emplace_back(Numbers(sf::Vector2f(200,65)));
   numbers[22].setTexture(*numbers_texture_p);
   numbers[22].set_number(-2);

   //B_thousand
   numbers.emplace_back(Numbers(sf::Vector2f(215,65)));
   numbers[23].setTexture(*numbers_texture_p);
   numbers[23].set_number(-2);


}


//CREATE_HUD_TIRES
void create_hud_tires(std::vector<Tires_heat> &tires_heat, sf::Texture *heat_texture_p){
    //FL
    tires_heat.emplace_back(Tires_heat(sf::Vector2f(604,521)));
    tires_heat[0].setTexture(*heat_texture_p);

    //FR
    tires_heat.emplace_back(Tires_heat(sf::Vector2f(638,521)));
    tires_heat[1].setTexture(*heat_texture_p);

    //RL
    tires_heat.emplace_back(Tires_heat(sf::Vector2f(604,564)));
    tires_heat[2].setTexture(*heat_texture_p);

    //RR
    tires_heat.emplace_back(Tires_heat(sf::Vector2f(638,564)));
    tires_heat[3].setTexture(*heat_texture_p);
}


//SPEEDOMETER
void speedometer_animation(std::vector<Numbers> &numbers,Car &car){
    numbers[2].set_number(car.speed_unity());
    if(car.speed_hundreds()>0){
        numbers[1].set_number(car.speed_dozens());
    }else{
        if(car.speed_dozens()==0){
            numbers[1].set_number(-1);
        }else{
            numbers[1].set_number(car.speed_dozens());
        }
    }
    if(car.speed_hundreds()==0){
        numbers[0].set_number(-1);
    }else{
        numbers[0].set_number(car.speed_hundreds());
    }
}


//TIME_MESUREMENT
void time_mesurement(std::vector<Numbers> &numbers,sf::Clock &counting_time, Tor &tor, Car &car){
    sf::Time time=counting_time.getElapsedTime();
    int current_time=time.asMilliseconds();
    int last_lap_time=tor.time_mesurement(car,counting_time);
    int best_time=tor.get_best_time();
    //std::cout<<best_time<<" "<<last_lap_time<<" "<<current_time<<std::endl;

    //animate_current
    numbers[9].set_number(current_time%10,tor.get_invalid_track_limits());
    current_time=current_time/10;
    numbers[8].set_number(current_time%10,tor.get_invalid_track_limits());
    current_time=current_time/10;
    numbers[7].set_number(current_time%10,tor.get_invalid_track_limits());
    current_time=current_time/10;
    numbers[6].set_number(current_time%10,tor.get_invalid_track_limits());
    current_time=current_time/10;
    numbers[5].set_number(current_time%6,tor.get_invalid_track_limits());
    current_time=current_time/6;
    numbers[4].set_number(current_time%10,tor.get_invalid_track_limits());
    current_time=current_time/10;
    numbers[3].set_number(current_time%6,tor.get_invalid_track_limits());

    if(last_lap_time<-1){
        numbers[16].set_number(-2);
        numbers[15].set_number(-2);
        numbers[14].set_number(-2);
        numbers[13].set_number(-2);
        numbers[12].set_number(-2);
        numbers[11].set_number(-2);
        numbers[10].set_number(-2);
    }else{
        numbers[16].set_number(last_lap_time%10);
        last_lap_time=last_lap_time/10;
        numbers[15].set_number(last_lap_time%10);
        last_lap_time=last_lap_time/10;
        numbers[14].set_number(last_lap_time%10);
        last_lap_time=last_lap_time/10;
        numbers[13].set_number(last_lap_time%10);
        last_lap_time=last_lap_time/10;
        numbers[12].set_number(last_lap_time%6);
        last_lap_time=last_lap_time/6;
        numbers[11].set_number(last_lap_time%10);
        last_lap_time=last_lap_time/10;
        numbers[10].set_number(last_lap_time%6);
    }

    if(best_time<-1){
        numbers[23].set_number(-2);
        numbers[22].set_number(-2);
        numbers[21].set_number(-2);
        numbers[20].set_number(-2);
        numbers[19].set_number(-2);
        numbers[18].set_number(-2);
        numbers[17].set_number(-2);
    }else{
        numbers[23].set_number(best_time%10);
        best_time=best_time/10;
        numbers[22].set_number(best_time%10);
        best_time=best_time/10;
        numbers[21].set_number(best_time%10);
        best_time=best_time/10;
        numbers[20].set_number(best_time%10);
        best_time=best_time/10;
        numbers[19].set_number(best_time%6);
        best_time=best_time/6;
        numbers[18].set_number(best_time%10);
        best_time=best_time/10;
        numbers[17].set_number(best_time%6);
    }

}


//RACE_ENGINEER
void race_engineer_messages(Race_engineer &race_engineer,Tor &tor, Car &car,Flag &flag, sf::Clock &messages_time,std::list<int>&message){
    sf::Time time=messages_time.getElapsedTime();

    //fastest_lap
    if(tor.get_new_best_lap()){message.emplace_front(3);}

    //chec_engine
    if(car.check_engine_status()&&!race_engineer.get_check_engine_said()){
        message.emplace_front(6);
        race_engineer.set_check_engine_said(true);
    }

    //tires_overheat
    if(car.get_FL_heat()>6.5 || car.get_FR_heat()>6.5 || car.get_RL_heat()>6.5 || car.get_RR_heat()>6.5){
        if(!race_engineer.get_are_tires_still_overheated()){message.emplace_front(2);}
        race_engineer.set_are_tires_still_overheated(true);
    }else{
        race_engineer.set_are_tires_still_overheated(false);
    }

    //tires_overheat
    if(car.get_brakes_heat()>6.5){
        if(!race_engineer.get_are_brakes_still_overheated()){message.emplace_front(1);}
        race_engineer.set_are_brakes_still_overheated(true);
    }else{
        race_engineer.set_are_brakes_still_overheated(false);
    }

    //yellow_flag
    if(flag.get_flag()==2){
        if(!race_engineer.get_is_yellow_flag_still()){message.emplace_front(5);}
        race_engineer.set_is_yellow_flag_still(true);
    }else{
        race_engineer.set_is_yellow_flag_still(false);
    }

    //red_flag
    if(flag.get_flag()==1){
        if(!race_engineer.get_is_red_flag_still()){message.emplace_front(4);}
        race_engineer.set_is_red_flag_still(true);
    }else{
        race_engineer.set_is_red_flag_still(false);
    }


    //std::cout<<message.size()<<std::endl;
    if(message.size()>0){
        if(time.asSeconds()>5 || message.back()==7){
            race_engineer.set_message(message.back());
            message.pop_back();
            messages_time.restart();
        }
    }else{
        if(time.asSeconds()>5){race_engineer.set_message(0);}
    }
}


//COLLISION
bool front_hit(float barrier_angle, float car_angle){
    float angle=abs(barrier_angle-car_angle);
    if((angle>45 && angle<135) || (angle>225 && angle<315)){
        return true;
    }else{
        return false;
    }
}

double get_a(double &x1, double &y1, double &x2, double &y2){
    return ((y1-y2)/(x1-x2));
}
double get_b(double &x1, double &y1, double &x2, double &y2){
    return (((y1*x2)-(y2*x1))/(x2-x1));
}
bool touch_90(double &x, double &y, double &left, double &right, double &up, double &down ){
    bool RET=false;
    if(x<right && x>left && y>up && y<down){
        RET=true;
    }
    return RET;
}
bool touch_45(double &x, double &y, double &aAB, double &bAB, double &aBC, double &bBC, double &aCD, double bCD, double &aDA, double &bDA){
    bool RET=false;
    double yAB, yBC, yCD, yDA;

    yAB=(aAB*x)+bAB;
    yBC=(aBC*x)+bBC;
    yCD=(aCD*x)+bCD;
    yDA=(aDA*x)+bDA;

    if(y>yAB){if(y>yDA){if(y<yBC){if(y<yCD){RET=true;}}}}

    return RET;
}
bool collision(sf::Sprite &object1, sf::Sprite &object2){

    bool hit=false;

    double left[3], right[3], up[3], down[3];
    double Ax[3], Bx[3], Cx[3], Dx[3];
    double Ay[3], By[3], Cy[3], Dy[3];
    double a[3][5], b[3][5];
    float angle[3];
    double high[3], width[3];
    double pi=3.14159265359;
    int compare_angle;
    double compare_angle1;

    compare_angle=object1.getRotation();
    object1.setRotation(0);
    sf::FloatRect object1_bounds = object1.getGlobalBounds();
    high[1]=object1_bounds.height;
    width[1]=object1_bounds.width;
    object1.setRotation(compare_angle);

    compare_angle1=object2.getRotation();
    object2.setRotation(0);
    sf::FloatRect object2_bounds = object2.getGlobalBounds();
    high[2]=object1_bounds.height;
    width[2]=object1_bounds.width;
    object2.setRotation(compare_angle1);

    object1_bounds = object1.getGlobalBounds();
    object2_bounds = object2.getGlobalBounds();

    left[1]=object1_bounds.left;
    right[1]=object1_bounds.left+object1_bounds.width;
    up[1]=object1_bounds.top;
    down[1]=object1_bounds.top+object1_bounds.height;
    angle[1]=object1.getRotation();

    left[2]=object2_bounds.left;
    right[2]=object2_bounds.left+object2_bounds.width;
    up[2]=object2_bounds.top;
    down[2]=object2_bounds.top+object2_bounds.height;
    angle[2]=object2.getRotation();



    for(int i=1; i<3; i++){
        //std::cout<<i<<" ";
        if(angle[i]>180){angle[i]=angle[i]-180;}
        if(angle[i]<90.0){
            Ay[i]=up[i];
            Ax[i]=left[i]+(sin(angle[i]*pi/180)*high[i]);

            Cy[i]=down[i];
            Cx[i]=right[i]-(sin(angle[i]*pi/180)*high[i]);

            By[i]=up[i]+(sin(angle[i]*pi/180)*width[i]);
            Bx[i]=right[i];

            Dy[i]=down[i]-(sin(angle[i]*pi/180)*width[i]);
            Dx[i]=left[i];
            //std::cout<<"A("<<Ax[i]<<","<<Ay[i]<<") B("<<Bx[i]<<","<<By[i]<<") C("<<Cx[i]<<","<<Cy[i]<<") D("<<Dx[i]<<","<<Dy[i]<<")"<<std::endl;
        }else{
            angle[i]=angle[i]-90.0;

            Ay[i]=up[i];
            Ax[i]=left[i]+(sin(angle[i]*pi/180)*width[i]);

            Cy[i]=down[i];
            Cx[i]=right[i]-(sin(angle[i]*pi/180)*width[i]);

            By[i]=up[i]+(sin((angle[i])*pi/180)*high[i]);
            Bx[i]=right[i];

            Dy[i]=down[i]-(sin(angle[i]*pi/180)*high[i]);
            Dx[i]=left[i];
            //std::cout<<"A("<<Ax[i]<<","<<Ay[i]<<") B("<<Bx[i]<<","<<By[i]<<") C("<<Cx[i]<<","<<Cy[i]<<") D("<<Dx[i]<<","<<Dy[i]<<")"<<std::endl;
        }

        a[i][1]=get_a(Ax[i],Ay[i],Bx[i],By[i]);
        a[i][2]=get_a(Bx[i],By[i],Cx[i],Cy[i]);
        a[i][3]=get_a(Cx[i],Cy[i],Dx[i],Dy[i]);
        a[i][4]=get_a(Dx[i],Dy[i],Ax[i],Ay[i]);
        b[i][1]=get_b(Ax[i],Ay[i],Bx[i],By[i]);
        b[i][2]=get_b(Bx[i],By[i],Cx[i],Cy[i]);
        b[i][3]=get_b(Cx[i],Cy[i],Dx[i],Dy[i]);
        b[i][4]=get_b(Dx[i],Dy[i],Ax[i],Ay[i]);

        //std::cout<<"a_AB "<<a[i][1]<<" "<<"a_BC "<<a[i][2]<<" "<<"a_CD "<<a[i][3]<<" "<<"a_DA "<<a[i][4]<<std::endl;
        //std::cout<<"b_AB "<<b[i][1]<<" "<<"b_BC "<<b[i][2]<<" "<<"b_CD "<<b[i][3]<<" "<<"b_DA "<<b[i][4]<<std::endl<<std::endl;
    }

    compare_angle=angle[1];
    //std::cout<<compare_angle<<" \n";
    if((compare_angle%90)==0){
        if(touch_90(Ax[2],Ay[2],left[1],right[1],up[1],down[1])==true ||
           touch_90(Bx[2],By[2],left[1],right[1],up[1],down[1])==true ||
           touch_90(Cx[2],Cy[2],left[1],right[1],up[1],down[1])==true ||
           touch_90(Dx[2],Dy[2],left[1],right[1],up[1],down[1])==true ){
            hit=true;
        }
    }else{
        if(touch_45(Ax[2],Ay[2],a[1][1],b[1][1],a[1][2],b[1][2],a[1][3],b[1][3],a[1][4],b[1][4])==true ||
           touch_45(Bx[2],By[2],a[1][1],b[1][1],a[1][2],b[1][2],a[1][3],b[1][3],a[1][4],b[1][4])==true ||
           touch_45(Cx[2],Cy[2],a[1][1],b[1][1],a[1][2],b[1][2],a[1][3],b[1][3],a[1][4],b[1][4])==true ||
           touch_45(Dx[2],Dy[2],a[1][1],b[1][1],a[1][2],b[1][2],a[1][3],b[1][3],a[1][4],b[1][4])==true ){
            hit=true;
        }
    }

    compare_angle=angle[2];
    //std::cout<<compare_angle<<" \n";
    if((compare_angle%90)==0){
        if(touch_90(Ax[1],Ay[1],left[2],right[2],up[2],down[2])==true ||
           touch_90(Bx[1],By[1],left[2],right[2],up[2],down[2])==true ||
           touch_90(Cx[1],Cy[1],left[2],right[2],up[2],down[2])==true ||
           touch_90(Dx[1],Dy[1],left[2],right[2],up[2],down[2])==true ){
            hit=true;
        }
    }else{
        if(touch_45(Ax[1],Ay[1],a[2][1],b[2][1],a[2][2],b[2][2],a[2][3],b[2][3],a[2][4],b[2][4])==true ||
           touch_45(Bx[1],By[1],a[2][1],b[2][1],a[2][2],b[2][2],a[2][3],b[2][3],a[2][4],b[2][4])==true ||
           touch_45(Cx[1],Cy[1],a[2][1],b[2][1],a[2][2],b[2][2],a[2][3],b[2][3],a[2][4],b[2][4])==true ||
           touch_45(Dx[1],Dy[1],a[2][1],b[2][1],a[2][2],b[2][2],a[2][3],b[2][3],a[2][4],b[2][4])==true ){
            hit=true;
        }

    }

    //std::cout<<std::endl;
    return hit;
}

bool car_collision(Middle_barrier &object1, Car &car){

    bool hit=false;

    double left[3], right[3], up[3], down[3];
    double Ax[3], Bx[3], Cx[3], Dx[3];
    double Ay[3], By[3], Cy[3], Dy[3];
    double a[3][5], b[3][5];
    float angle[3];
    double high[3], width[3];
    double pi=3.14159265359;
    int compare_angle;

    compare_angle=object1.getRotation();
    object1.setRotation(0);
    sf::FloatRect object1_bounds = object1.getGlobalBounds();
    high[1]=object1_bounds.height;
    width[1]=object1_bounds.width;
    object1.setRotation(compare_angle);

    sf::FloatRect object2_bounds;
    //high[2]=object1_bounds.height;
    //width[2]=object1_bounds.width;
    car.car_size(high[2],width[2]);

    object1_bounds = object1.getGlobalBounds();
    object2_bounds = car.getGlobalBounds();

    left[1]=object1_bounds.left;
    right[1]=object1_bounds.left+object1_bounds.width;
    up[1]=object1_bounds.top;
    down[1]=object1_bounds.top+object1_bounds.height;
    angle[1]=object1.getRotation();

    left[2]=object2_bounds.left;
    right[2]=object2_bounds.left+object2_bounds.width;
    up[2]=object2_bounds.top;
    down[2]=object2_bounds.top+object2_bounds.height;
    angle[2]=car.getRotation();



    for(int i=1; i<3; i++){
        //std::cout<<i<<" ";
        if(angle[i]>180){angle[i]=angle[i]-180;}
        if(angle[i]<90.0){
            Ay[i]=up[i];
            Ax[i]=left[i]+(sin(angle[i]*pi/180)*high[i]);

            Cy[i]=down[i];
            Cx[i]=right[i]-(sin(angle[i]*pi/180)*high[i]);

            By[i]=up[i]+(sin(angle[i]*pi/180)*width[i]);
            Bx[i]=right[i];

            Dy[i]=down[i]-(sin(angle[i]*pi/180)*width[i]);
            Dx[i]=left[i];
            //std::cout<<"A("<<Ax[i]<<","<<Ay[i]<<") B("<<Bx[i]<<","<<By[i]<<") C("<<Cx[i]<<","<<Cy[i]<<") D("<<Dx[i]<<","<<Dy[i]<<")"<<std::endl;
        }else{
            angle[i]=angle[i]-90.0;

            Ay[i]=up[i];
            Ax[i]=left[i]+(sin(angle[i]*pi/180)*width[i]);

            Cy[i]=down[i];
            Cx[i]=right[i]-(sin(angle[i]*pi/180)*width[i]);

            By[i]=up[i]+(sin((angle[i])*pi/180)*high[i]);
            Bx[i]=right[i];

            Dy[i]=down[i]-(sin(angle[i]*pi/180)*high[i]);
            Dx[i]=left[i];
            //std::cout<<"A("<<Ax[i]<<","<<Ay[i]<<") B("<<Bx[i]<<","<<By[i]<<") C("<<Cx[i]<<","<<Cy[i]<<") D("<<Dx[i]<<","<<Dy[i]<<")"<<std::endl;
        }

        a[i][1]=get_a(Ax[i],Ay[i],Bx[i],By[i]);
        a[i][2]=get_a(Bx[i],By[i],Cx[i],Cy[i]);
        a[i][3]=get_a(Cx[i],Cy[i],Dx[i],Dy[i]);
        a[i][4]=get_a(Dx[i],Dy[i],Ax[i],Ay[i]);
        b[i][1]=get_b(Ax[i],Ay[i],Bx[i],By[i]);
        b[i][2]=get_b(Bx[i],By[i],Cx[i],Cy[i]);
        b[i][3]=get_b(Cx[i],Cy[i],Dx[i],Dy[i]);
        b[i][4]=get_b(Dx[i],Dy[i],Ax[i],Ay[i]);

        //std::cout<<"a_AB "<<a[i][1]<<" "<<"a_BC "<<a[i][2]<<" "<<"a_CD "<<a[i][3]<<" "<<"a_DA "<<a[i][4]<<std::endl;
        //std::cout<<"b_AB "<<b[i][1]<<" "<<"b_BC "<<b[i][2]<<" "<<"b_CD "<<b[i][3]<<" "<<"b_DA "<<b[i][4]<<std::endl<<std::endl;
    }

    compare_angle=angle[1];
    //std::cout<<compare_angle<<" \n";
    if((compare_angle%90)==0){
        if(touch_90(Ax[2],Ay[2],left[1],right[1],up[1],down[1])==true ||
           touch_90(Bx[2],By[2],left[1],right[1],up[1],down[1])==true ||
           touch_90(Cx[2],Cy[2],left[1],right[1],up[1],down[1])==true ||
           touch_90(Dx[2],Dy[2],left[1],right[1],up[1],down[1])==true ){
            hit=true;
        }
    }else{
        if(touch_45(Ax[2],Ay[2],a[1][1],b[1][1],a[1][2],b[1][2],a[1][3],b[1][3],a[1][4],b[1][4])==true ||
           touch_45(Bx[2],By[2],a[1][1],b[1][1],a[1][2],b[1][2],a[1][3],b[1][3],a[1][4],b[1][4])==true ||
           touch_45(Cx[2],Cy[2],a[1][1],b[1][1],a[1][2],b[1][2],a[1][3],b[1][3],a[1][4],b[1][4])==true ||
           touch_45(Dx[2],Dy[2],a[1][1],b[1][1],a[1][2],b[1][2],a[1][3],b[1][3],a[1][4],b[1][4])==true ){
            hit=true;
        }
    }

    compare_angle=angle[2];
    //std::cout<<compare_angle<<" \n";
    if((compare_angle%90)==0){
        if(touch_90(Ax[1],Ay[1],left[2],right[2],up[2],down[2])==true ||
           touch_90(Bx[1],By[1],left[2],right[2],up[2],down[2])==true ||
           touch_90(Cx[1],Cy[1],left[2],right[2],up[2],down[2])==true ||
           touch_90(Dx[1],Dy[1],left[2],right[2],up[2],down[2])==true ){
            hit=true;
        }
    }else{
        if(touch_45(Ax[1],Ay[1],a[2][1],b[2][1],a[2][2],b[2][2],a[2][3],b[2][3],a[2][4],b[2][4])==true ||
           touch_45(Bx[1],By[1],a[2][1],b[2][1],a[2][2],b[2][2],a[2][3],b[2][3],a[2][4],b[2][4])==true ||
           touch_45(Cx[1],Cy[1],a[2][1],b[2][1],a[2][2],b[2][2],a[2][3],b[2][3],a[2][4],b[2][4])==true ||
           touch_45(Dx[1],Dy[1],a[2][1],b[2][1],a[2][2],b[2][2],a[2][3],b[2][3],a[2][4],b[2][4])==true ){
            hit=true;
        }

    }

    //std::cout<<std::endl;
    return hit;
}


#endif // FUNCTIONS_H
