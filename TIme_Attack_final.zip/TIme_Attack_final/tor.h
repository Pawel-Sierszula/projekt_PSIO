#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <memory>
#include <math.h>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>

#ifndef TOR_H
#define TOR_H

class Tor: public sf::Sprite, sf::Texture{
private:
//variables
    bool FL_wheel_off=false;
    bool FR_wheel_off=false;
    bool RL_wheel_off=false;
    bool RR_wheel_off=false;
    bool all_wheels_off=false;

    bool sector_2=false;
    bool sector_3=false;
    int lap_time=-2;
    int best_time=3600001;
    bool new_best_lap=false;

public:
//construktor
    Tor(sf::Vector2f position){
        setScale(1,1);
        setOrigin(3000,3000);
        setPosition(position);
    }
    ~Tor(){}

//methods

 //track_limits
    bool limits_sector0(float x, float y){
        bool RET=false;
        if((pow(425,2))>(pow(x-(getPosition().x-265),2)+pow(y-(getPosition().y+722),2))){RET=true;}
        if((pow(100,2))>(pow(x-(getPosition().x-265),2)+pow(y-(getPosition().y+722),2))){RET=false;}
        if(y<(getPosition().y+723)){RET=false;}
        if(x<(getPosition().x-265)){RET=false;}
        if((y>getPosition().y-776)&&(y<getPosition().y+723)&&(x>getPosition().x-164)&&(x<getPosition().x+161)){RET=true;}
        return RET;
    }
    bool limits_sector1(float x, float y){
        bool RET=false;

        if((pow(534.5,2))>(pow(x-(getPosition().x-1061.5),2)+pow(y-(getPosition().y-1407.5),2))){RET=true;}
        if((x>getPosition().x-1061.5)&&(x<getPosition().x-240)&&(y<getPosition().y-877)&&(y>getPosition().y-1944)){RET=true;}
        if((pow(210,2))>(pow(x-(getPosition().x-1061.5),2)+pow(y-(getPosition().y-1407.5),2))){RET=false;}
        if((x>getPosition().x-1061.5)&&(x<getPosition().x-240)&&(y<getPosition().y-1201)&&(y>getPosition().y-1620)){RET=false;}

        return RET;
    }
    bool limits_sector2(float x, float y){
        bool RET=false;

        if((pow(1170,2))>(pow(x-(getPosition().x-264),2)+pow(y-(getPosition().y-776),2))){RET=true;}
        if((pow(845,2))>(pow(x-(getPosition().x-264),2)+pow(y-(getPosition().y-776),2))){RET=false;}
        if((pow(426,2))>(pow(x-(getPosition().x-264),2)+pow(y-(getPosition().y-776),2))){RET=true;}
        if((pow(101,2))>(pow(x-(getPosition().x-264),2)+pow(y-(getPosition().y-776),2))){RET=false;}
        if(y>(getPosition().y-776)){RET=false;}
        if(x<(getPosition().x-246)){RET=false;}
        if((y>getPosition().y-776)&&(y<getPosition().y-670)&&(x>getPosition().x+587)&&(x<getPosition().x+912)){RET=true;}
        return RET;
    }
    bool limits_sector3(float x, float y){
        bool RET=false;
        if((pow(425,2))>(pow(x-(getPosition().x+1012),2)+pow(y-(getPosition().y-670),2))){RET=true;}
        if((pow(100,2))>(pow(x-(getPosition().x+1012),2)+pow(y-(getPosition().y-670),2))){RET=false;}
        if(y<(getPosition().y-670)){RET=false;}
        if(x>(getPosition().x+1012)){RET=false;}
        if((y>getPosition().y-570)&&(y<getPosition().y-245)&&(x>getPosition().x+1012)&&(x<getPosition().x+1203)){RET=true;}
        return RET;
    }
    bool limits_sector4(float x, float y){
        bool RET=false;
        if((pow(426,2))>(pow(x-(getPosition().x+1203),2)+pow(y-(getPosition().y-145),2))){RET=true;}
        if((pow(102,2))>(pow(x-(getPosition().x+1203),2)+pow(y-(getPosition().y-145),2))){RET=false;}
        if(y>(getPosition().y-145)){RET=false;}
        if(x<(getPosition().x+1203)){RET=false;}
        if((y>getPosition().y-145)&&(y<getPosition().y+355)&&(x>getPosition().x+1304)&&(x<getPosition().x+1630)){RET=true;}
        return RET;
    }
    bool limits_sector5(float x, float y){
        bool RET=false;
        if((pow(355,2))>(pow(x-(getPosition().x+1276),2)+pow(y-(getPosition().y+355),2))){RET=true;}
        if((pow(30,2))>(pow(x-(getPosition().x+1276),2)+pow(y-(getPosition().y+355),2))){RET=false;}
        if(y<(getPosition().y+355)){RET=false;}
        if(y>((x-(getPosition().x-400))-1021+getPosition().y-300)){RET=false;}
        if((y>((  x-(getPosition().x-400) )-1021+getPosition().y-300))&&
           (y>((-(x-(getPosition().x-400)))+2371+getPosition().y-300))&&
           (y<((  x-(getPosition().x-400) )+1830+getPosition().y-300))&&
           (y<((-(x-(getPosition().x-400)))+2809+getPosition().y-300))){

           RET=true;
        }
        return RET;
    }
    bool limits_sector6(float x, float y){
        bool RET=false;
        if((pow(355,2))>(pow(x-(getPosition().x-150),2)+pow(y-(getPosition().y+1778),2))){RET=true;}
        if((pow(30,2))>(pow(x-(getPosition().x-150),2)+pow(y-(getPosition().y+1778),2))){RET=false;}
        if(y<((x-(getPosition().x-400))+1830+getPosition().y-300)){RET=false;}
        if(y<((-(x-(getPosition().x-400)))+2328+getPosition().y-300)){RET=false;}
        if((y>((  x-(getPosition().x-400) )+1874+getPosition().y-300))&&
           (y<((-(x-(getPosition().x-400)))+2328+getPosition().y-300))&&
           (y<((  x-(getPosition().x-400) )+2312+getPosition().y-300))&&
           (y>((-(x-(getPosition().x-400)))+1139+getPosition().y-300))){

           RET=true;
        }
        return RET;
    }
    bool limits_sector7(float x, float y){
        bool RET=false;
        if((pow(357,2))>(pow(x-(getPosition().x-743),2)+pow(y-(getPosition().y+1182),2))){RET=true;}
        if((pow(34,2))>(pow(x-(getPosition().x-743),2)+pow(y-(getPosition().y+1182),2))){RET=false;}
        if(y>((-(x-(getPosition().x-400)))+1139+getPosition().y-300)){RET=false;}
        if(x>(getPosition().x-743)){RET=false;}
        if((y>getPosition().y+824)&&(y<getPosition().y+1149)&&(x>getPosition().x-743)&&(x<getPosition().x-265)){RET=true;}
        return RET;
    }
    bool limits_pitlane(float x, float y){
        bool RET=false;
        if((y>getPosition().y-877)&&(y<getPosition().y+826)&&(x>getPosition().x-1072)&&(x<getPosition().x-356)){RET=true;}
        return RET;
    }

    bool limits_sectors_togeather(float x, float y){
        bool RET=false;
        if(limits_sector0(x,y)){RET=true;}
        if(limits_sector1(x,y)){RET=true;}
        if(limits_sector2(x,y)){RET=true;}
        if(limits_sector3(x,y)){RET=true;}
        if(limits_sector4(x,y)){RET=true;}
        if(limits_sector5(x,y)){RET=true;}
        if(limits_sector6(x,y)){RET=true;}
        if(limits_sector7(x,y)){RET=true;}
        if(limits_pitlane(x,y)){RET=true;}
        return RET;
    }
    void track_limits(sf::Sprite car){
        bool Ain=false;
        bool Bin=false;
        bool Cin=false;
        bool Din=false;

    //calculate_car_corrners
        double left, right, up, down;
        double Ax, Bx, Cx, Dx;
        double Ay, By, Cy, Dy;
        float angle;
        double high, width;
        double pi=3.14159265359;
        int compare_angle;

        compare_angle=car.getRotation();
        car.setRotation(0);
        sf::FloatRect car_bounds = car.getGlobalBounds();
        high=car_bounds.height;
        width=car_bounds.width;
        car.setRotation(compare_angle);

        car_bounds = car.getGlobalBounds();

        left=car_bounds.left;
        right=car_bounds.left+car_bounds.width;
        up=car_bounds.top;
        down=car_bounds.top+car_bounds.height;
        angle=car.getRotation();

        if(angle>180){angle=angle-180;}
        if(angle<90.0){
            Ay=up;
            Ax=left+(sin(angle*pi/180)*high);

            Cy=down;
            Cx=right-(sin(angle*pi/180)*high);

            By=up+(sin(angle*pi/180)*width);
            Bx=right;

            Dy=down-(sin(angle*pi/180)*width);
            Dx=left;

        }else{
            angle=angle-90.0;

            Ay=up;
            Ax=left+(sin(angle*pi/180)*width);

            Cy=down;
            Cx=right-(sin(angle*pi/180)*width);

            By=up+(sin((angle)*pi/180)*high);
            Bx=right;

            Dy=down-(sin(angle*pi/180)*high);
            Dx=left;
        }

      //check_layers
        if(limits_sectors_togeather(Ax,Ay)){Ain=true;}
        if(limits_sectors_togeather(Bx,By)){Bin=true;}
        if(limits_sectors_togeather(Cx,Cy)){Cin=true;}
        if(limits_sectors_togeather(Dx,Dy)){Din=true;}

        if(car.getRotation()>=0 && car.getRotation()<90){
            FL_wheel_off=!Ain;
            FR_wheel_off=!Bin;
            RL_wheel_off=!Din;
            RR_wheel_off=!Cin;
        }
        if(car.getRotation()>=90 && car.getRotation()<180){
            FL_wheel_off=!Bin;
            FR_wheel_off=!Cin;
            RL_wheel_off=!Ain;
            RR_wheel_off=!Din;
        }
        if(car.getRotation()>=180 && car.getRotation()<270){
            FL_wheel_off=!Cin;
            FR_wheel_off=!Din;
            RL_wheel_off=!Bin;
            RR_wheel_off=!Ain;
        }
        if(car.getRotation()>=270 && car.getRotation()<360){
            FL_wheel_off=!Din;
            FR_wheel_off=!Ain;
            RL_wheel_off=!Cin;
            RR_wheel_off=!Bin;
        }

        if(FL_wheel_off && FR_wheel_off && RL_wheel_off && RR_wheel_off){
            all_wheels_off=true;
        }

        //if(FL_wheel_off){std::cout<<"A_out ";}else{std::cout<<"A__in ";}
        //if(FR_wheel_off){std::cout<<"B_out ";}else{std::cout<<"B__in ";}
        //if(RL_wheel_off){std::cout<<"C_out ";}else{std::cout<<"C__in ";}
        //if(RR_wheel_off){std::cout<<"D_out ";}else{std::cout<<"D__in ";}
        //std::cout<<std::endl;

    }

    bool pitlane_detection(sf::Sprite car){


    //calculate_car_corrners
        double left, right, up, down;
        double Ax, Bx, Cx, Dx;
        double Ay, By, Cy, Dy;
        float angle;
        double high, width;
        double pi=3.14159265359;
        int compare_angle;

        compare_angle=car.getRotation();
        car.setRotation(0);
        sf::FloatRect car_bounds = car.getGlobalBounds();
        high=car_bounds.height;
        width=car_bounds.width;
        car.setRotation(compare_angle);

        car_bounds = car.getGlobalBounds();

        left=car_bounds.left;
        right=car_bounds.left+car_bounds.width;
        up=car_bounds.top;
        down=car_bounds.top+car_bounds.height;
        angle=car.getRotation();

        if(angle>180){angle=angle-180;}
        if(angle<90.0){
            Ay=up;
            Ax=left+(sin(angle*pi/180)*high);

            Cy=down;
            Cx=right-(sin(angle*pi/180)*high);

            By=up+(sin(angle*pi/180)*width);
            Bx=right;

            Dy=down-(sin(angle*pi/180)*width);
            Dx=left;

        }else{
            angle=angle-90.0;

            Ay=up;
            Ax=left+(sin(angle*pi/180)*width);

            Cy=down;
            Cx=right-(sin(angle*pi/180)*width);

            By=up+(sin((angle)*pi/180)*high);
            Bx=right;

            Dy=down-(sin(angle*pi/180)*high);
            Dx=left;
        }
        if(limits_pitlane(Ax,Ay)&&limits_pitlane(Bx,By)&&limits_pitlane(Cx,Cy)&&limits_pitlane(Dx,Dy)){
            return true;
        }else{
            return false;
        }
    }

 //return_limits_status
    bool get_FL_wheel_position(){return FL_wheel_off;}
    bool get_FR_wheel_position(){return FR_wheel_off;}
    bool get_RL_wheel_position(){return RL_wheel_off;}
    bool get_RR_wheel_position(){return RR_wheel_off;}
    bool get_invalid_track_limits(){return all_wheels_off;}


 //track_sectors_detection
    bool sector_1_detection(float x, float y){
        bool RET=false;
        if((y>getPosition().y-162)&&(y<getPosition().y-135)&&(x>getPosition().x-1350)&&(x<getPosition().x+350)){RET=true;}
        return RET;
    }
    bool sector_2_detection(float x, float y){
        bool RET=false;
        if((y>getPosition().y+150)&&(y<getPosition().y+200)&&(x>getPosition().x+1130)&&(x<getPosition().x+1830)){RET=true;}
        return RET;
    }
    bool sector_3_detection(float x, float y){
        bool RET=false;
        if((y>getPosition().y+1550)&&(y<getPosition().y+2500)&&(x>getPosition().x-160)&&(x<getPosition().x-130)){RET=true;}
        return RET;
    }

    int time_mesurement(sf::Sprite car, sf::Clock &counting_time){
        //Time
            sf::Time time;

        //calculate_car_corrners
            double left, right, up, down;
            double Ax, Bx, Cx, Dx;
            double Ay, By, Cy, Dy;
            float angle;
            double high, width;
            double pi=3.14159265359;
            int compare_angle;

            compare_angle=car.getRotation();
            car.setRotation(0);
            sf::FloatRect car_bounds = car.getGlobalBounds();
            high=car_bounds.height;
            width=car_bounds.width;
            car.setRotation(compare_angle);

            car_bounds = car.getGlobalBounds();

            left=car_bounds.left;
            right=car_bounds.left+car_bounds.width;
            up=car_bounds.top;
            down=car_bounds.top+car_bounds.height;
            angle=car.getRotation();

            if(angle>180){angle=angle-180;}
            if(angle<90.0){
                Ay=up;
                Ax=left+(sin(angle*pi/180)*high);

                Cy=down;
                Cx=right-(sin(angle*pi/180)*high);

                By=up+(sin(angle*pi/180)*width);
                Bx=right;

                Dy=down-(sin(angle*pi/180)*width);
                Dx=left;

            }else{
                angle=angle-90.0;

                Ay=up;
                Ax=left+(sin(angle*pi/180)*width);

                Cy=down;
                Cx=right-(sin(angle*pi/180)*width);

                By=up+(sin((angle)*pi/180)*high);
                Bx=right;

                Dy=down-(sin(angle*pi/180)*high);
                Dx=left;
            }

            if(sector_1_detection(Ax,Ay) || sector_1_detection(Bx,By) || sector_1_detection(Cx,Cy) || sector_1_detection(Dx,Dy)){
                if(sector_2 && sector_3){
                    time=counting_time.getElapsedTime();
                    lap_time=time.asMilliseconds();
                    if(!all_wheels_off){
                        if(lap_time<best_time){
                            best_time=lap_time;
                            new_best_lap=true;
                        }else{
                            new_best_lap=false;
                        }
                    }else{
                        new_best_lap=false;
                    }
                    counting_time.restart();
                    all_wheels_off=false;
                }else{
                    new_best_lap=false;
                }
                sector_2=false;
            }
            if(sector_2_detection(Ax,Ay) || sector_2_detection(Bx,By) || sector_2_detection(Cx,Cy) || sector_2_detection(Dx,Dy)){
                sector_2=true;
                sector_3=false;
            }
            if(sector_3_detection(Ax,Ay) || sector_3_detection(Bx,By) || sector_3_detection(Cx,Cy) || sector_3_detection(Dx,Dy)){
                sector_3=true;
            }

            //if(sector_2){std::cout<<"sector_2_on  ";}else{std::cout<<"sector_2_off ";}
            //if(sector_3){std::cout<<"sector_3_on  ";}else{std::cout<<"sector_3_off ";}
            return lap_time;
    }

    int get_best_time(){
        if(best_time>3600000){
            return -2;
        }else{
            return best_time;
        }
    }
    bool get_new_best_lap(){return  new_best_lap;}

 //move_camera
    void move_camera(sf::Vector2f movement){
        move(movement);
    }


};

class Boxes: public sf::Sprite, sf::Texture{
public:
//variables
    double pos_x;
    double pos_y;

public:
//construktor
    Boxes(sf::Vector2f position){
        setScale(1,1);
        setOrigin(0,0);
        setPosition(position);
    }

    ~Boxes(){}

//metods
    void move_camera(sf::Vector2f movement){
        move(movement);
    }

    double get_a(double &x1, double &y1, double &x2, double &y2){
        return ((y1-y2)/(x1-x2));
    }
    double get_b(double &x1, double &y1, double &x2, double &y2){
        return (((y1*x2)-(y2*x1))/(x2-x1));
    }
    bool touch_90(double &x, double &y, double &left, double &right, double &up, double &down ){
        bool RET=false;
        if(x<right && x>left && y>up && y<down){
            RET=true;
        }
        return RET;
    }
    bool touch_45(double &x, double &y, double &aAB, double &bAB, double &aBC, double &bBC, double &aCD, double bCD, double &aDA, double &bDA){
        bool RET=false;
        double yAB, yBC, yCD, yDA;

        yAB=(aAB*x)+bAB;
        yBC=(aBC*x)+bBC;
        yCD=(aCD*x)+bCD;
        yDA=(aDA*x)+bDA;

        if(y>yAB){if(y>yDA){if(y<yBC){if(y<yCD){RET=true;}}}}

        return RET;
    }
    bool hit(sf::Sprite car){
        bool hit=false;

        double left[3], right[3], up[3], down[3];
        double Ax[3], Bx[3], Cx[3], Dx[3];
        double Ay[3], By[3], Cy[3], Dy[3];
        double a[3][5], b[3][5];
        float angle[3];
        double high[3], width[3];
        double pi=3.14159265359;
        int compare_angle;
        //double compare_angle1;

        compare_angle=car.getRotation();
        car.setRotation(0);
        sf::FloatRect object1_bounds = car.getGlobalBounds();
        high[1]=object1_bounds.height;
        width[1]=object1_bounds.width;
        car.setRotation(compare_angle);

        compare_angle=getRotation();
        setRotation(0);
        sf::FloatRect object2_bounds = getGlobalBounds();
        high[2]=object2_bounds.height;
        width[2]=object2_bounds.width;
        setRotation(compare_angle);

        object1_bounds = car.getGlobalBounds();
        object2_bounds = getGlobalBounds();

        left[1]=object1_bounds.left;
        right[1]=object1_bounds.left+object1_bounds.width;
        up[1]=object1_bounds.top;
        down[1]=object1_bounds.top+object1_bounds.height;
        angle[1]=car.getRotation();

        left[2]=object2_bounds.left;
        right[2]=object2_bounds.left+object2_bounds.width;
        up[2]=object2_bounds.top;
        down[2]=object2_bounds.top+object2_bounds.height;
        angle[2]=getRotation();



        for(int i=1; i<3; i++){
            //std::cout<<i<<" ";
            if(angle[i]>180){angle[i]=angle[i]-180;}
            if(angle[i]<90.0){
                Ay[i]=up[i];
                Ax[i]=left[i]+(sin(angle[i]*pi/180)*high[i]);

                Cy[i]=down[i];
                Cx[i]=right[i]-(sin(angle[i]*pi/180)*high[i]);

                By[i]=up[i]+(sin(angle[i]*pi/180)*width[i]);
                Bx[i]=right[i];

                Dy[i]=down[i]-(sin(angle[i]*pi/180)*width[i]);
                Dx[i]=left[i];
                //std::cout<<"A("<<Ax[i]<<","<<Ay[i]<<") B("<<Bx[i]<<","<<By[i]<<") C("<<Cx[i]<<","<<Cy[i]<<") D("<<Dx[i]<<","<<Dy[i]<<")"<<std::endl;
            }else{
                angle[i]=angle[i]-90.0;

                Ay[i]=up[i];
                Ax[i]=left[i]+(sin(angle[i]*pi/180)*width[i]);

                Cy[i]=down[i];
                Cx[i]=right[i]-(sin(angle[i]*pi/180)*width[i]);

                By[i]=up[i]+(sin((angle[i])*pi/180)*high[i]);
                Bx[i]=right[i];

                Dy[i]=down[i]-(sin(angle[i]*pi/180)*high[i]);
                Dx[i]=left[i];
                //std::cout<<"A("<<Ax[i]<<","<<Ay[i]<<") B("<<Bx[i]<<","<<By[i]<<") C("<<Cx[i]<<","<<Cy[i]<<") D("<<Dx[i]<<","<<Dy[i]<<")"<<std::endl;
            }

            a[i][1]=get_a(Ax[i],Ay[i],Bx[i],By[i]);
            a[i][2]=get_a(Bx[i],By[i],Cx[i],Cy[i]);
            a[i][3]=get_a(Cx[i],Cy[i],Dx[i],Dy[i]);
            a[i][4]=get_a(Dx[i],Dy[i],Ax[i],Ay[i]);
            b[i][1]=get_b(Ax[i],Ay[i],Bx[i],By[i]);
            b[i][2]=get_b(Bx[i],By[i],Cx[i],Cy[i]);
            b[i][3]=get_b(Cx[i],Cy[i],Dx[i],Dy[i]);
            b[i][4]=get_b(Dx[i],Dy[i],Ax[i],Ay[i]);

            //std::cout<<"a_AB "<<a[i][1]<<" "<<"a_BC "<<a[i][2]<<" "<<"a_CD "<<a[i][3]<<" "<<"a_DA "<<a[i][4]<<std::endl;
            //std::cout<<"b_AB "<<b[i][1]<<" "<<"b_BC "<<b[i][2]<<" "<<"b_CD "<<b[i][3]<<" "<<"b_DA "<<b[i][4]<<std::endl<<std::endl;
        }

        compare_angle=angle[1];
        //std::cout<<compare_angle<<" \n";
        if((compare_angle%90)==0){
            if(touch_90(Ax[2],Ay[2],left[1],right[1],up[1],down[1])==true ||
               touch_90(Bx[2],By[2],left[1],right[1],up[1],down[1])==true ||
               touch_90(Cx[2],Cy[2],left[1],right[1],up[1],down[1])==true ||
               touch_90(Dx[2],Dy[2],left[1],right[1],up[1],down[1])==true ){
                hit=true;
            }
        }else{
            if(touch_45(Ax[2],Ay[2],a[1][1],b[1][1],a[1][2],b[1][2],a[1][3],b[1][3],a[1][4],b[1][4])==true ||
               touch_45(Bx[2],By[2],a[1][1],b[1][1],a[1][2],b[1][2],a[1][3],b[1][3],a[1][4],b[1][4])==true ||
               touch_45(Cx[2],Cy[2],a[1][1],b[1][1],a[1][2],b[1][2],a[1][3],b[1][3],a[1][4],b[1][4])==true ||
               touch_45(Dx[2],Dy[2],a[1][1],b[1][1],a[1][2],b[1][2],a[1][3],b[1][3],a[1][4],b[1][4])==true ){
                hit=true;
            }
        }

        compare_angle=angle[2];
        //std::cout<<compare_angle<<" \n";
        if((compare_angle%90)==0){
            if(touch_90(Ax[1],Ay[1],left[2],right[2],up[2],down[2])==true ||
               touch_90(Bx[1],By[1],left[2],right[2],up[2],down[2])==true ||
               touch_90(Cx[1],Cy[1],left[2],right[2],up[2],down[2])==true ||
               touch_90(Dx[1],Dy[1],left[2],right[2],up[2],down[2])==true ){
                hit=true;
            }
        }else{
            if(touch_45(Ax[1],Ay[1],a[2][1],b[2][1],a[2][2],b[2][2],a[2][3],b[2][3],a[2][4],b[2][4])==true ||
               touch_45(Bx[1],By[1],a[2][1],b[2][1],a[2][2],b[2][2],a[2][3],b[2][3],a[2][4],b[2][4])==true ||
               touch_45(Cx[1],Cy[1],a[2][1],b[2][1],a[2][2],b[2][2],a[2][3],b[2][3],a[2][4],b[2][4])==true ||
               touch_45(Dx[1],Dy[1],a[2][1],b[2][1],a[2][2],b[2][2],a[2][3],b[2][3],a[2][4],b[2][4])==true ){
                hit=true;
            }

        }

        //std::cout<<std::endl;
        return hit;
    }


};

#endif // TOR_H
