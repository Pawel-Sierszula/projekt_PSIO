#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <memory>
#include <math.h>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>


#ifndef HUD_H
#define HUD_H

class Hud: public sf::Sprite, sf::Texture{

public:

    Hud(sf::Vector2f position){
        setScale(0.1,0.1);
        setOrigin(0,0);
        setPosition(position);
    }

    ~Hud(){}
};

class Rpm: public sf::Sprite, sf::Texture{
private:

    float rpm_volume=0;
    float max_rpm_volume=1260;

public:

    Rpm(sf::Vector2f position){
        setScale(0.15,1);
        setOrigin(0,0);
        setPosition(position);
    }

    ~Rpm(){}

    float get_max_rpm(){return max_rpm_volume;}

    void animate_rpm(float engine_rpm){
        rpm_volume=engine_rpm;
        //if(gas_pedal){
        //    if(rpm_volume<1260){rpm_volume=rpm_volume+0.1;}
        //}else{
        //    if(rpm_volume>0){rpm_volume=rpm_volume-0.1;}
        //}

        setTextureRect(sf::IntRect(0,0,rpm_volume,100));
    }

};

class Gears: public sf::Sprite, sf::Texture{

public:

    Gears(sf::Vector2f position){
        setScale(0.05,0.05);
        setOrigin(0,0);
        setPosition(position);
    }

    ~Gears(){}

    void set_gear(int gear){
        switch(gear){
            case -1:{
                setTextureRect(sf::IntRect(0, 0, 1000, 1000));
                break;
            }

            case 0:{
                setTextureRect(sf::IntRect(1000,0,1000,1000));
                break;
            }

            case 1:{
                setTextureRect(sf::IntRect(2000,0,1000,1000));
                break;
            }

            case 2:{
                setTextureRect(sf::IntRect(3000,0,1000,1000));
                break;
            }

            case 3:{
                setTextureRect(sf::IntRect(4000,0,1000,1000));
                break;
            }

            case 4:{
                setTextureRect(sf::IntRect(5000,0,1000,1000));
                break;
            }

            case 5:{
                setTextureRect(sf::IntRect(6000,0,1000,1000));
                break;
            }
        }
    }

};

class Check_engine: public sf::Sprite, sf::Texture{

public:

    Check_engine(sf::Vector2f position){
        setScale(0.1,0.1);
        setOrigin(0,0);
        setPosition(position);
    }

    ~Check_engine(){}

    void status(bool check_engine){
        if(check_engine){
            setTextureRect(sf::IntRect(1000, 0, 1000, 1000));
        }else{
            setTextureRect(sf::IntRect(0,0,1000,1000));
        }
    }

};

class Engine_and_downshift: public sf::Sprite, sf::Texture{

public:

    Engine_and_downshift(sf::Vector2f position){
        setScale(0.2,0.2);
        setOrigin(0,0);
        setPosition(position);
    }

    ~Engine_and_downshift(){}

    void status(bool engine_status, bool downshift, bool check_engine){
        if(!check_engine){
            if(!engine_status && !downshift){setTextureRect(sf::IntRect(0,0,200,100));}
            if(!engine_status &&  downshift){setTextureRect(sf::IntRect(0,100,200,100));}
            if( engine_status && !downshift){setTextureRect(sf::IntRect(0,200,200,100));}
            if( engine_status &&  downshift){setTextureRect(sf::IntRect(0,300,200,100));}
        }else{
            setTextureRect(sf::IntRect(0,400,200,100));
        }
    }

};

class Numbers: public sf::Sprite, sf::Texture{

public:

    Numbers(sf::Vector2f position){
        setScale(0.03,0.03);
        setOrigin(0,0);
        setPosition(position);
    }

    ~Numbers(){}

    void set_number(int number,bool track_limits=false){
        if(!track_limits){
            switch(number){
                case 1:{
                    setTextureRect(sf::IntRect(0,0,500,1000));
                    break;
                }

                case 2:{
                    setTextureRect(sf::IntRect(500,0,500,1000));
                    break;
                }

                case 3:{
                    setTextureRect(sf::IntRect(1000,0,500,1000));
                    break;
                }

                case 4:{
                    setTextureRect(sf::IntRect(1500,0,500,1000));
                    break;
                }

                case 5:{
                    setTextureRect(sf::IntRect(2000,0,500,1000));
                    break;
                }

                case 6:{
                    setTextureRect(sf::IntRect(2500,0,500,1000));
                    break;
                }

                case 7:{
                    setTextureRect(sf::IntRect(3000,0,500,1000));
                    break;
                }

                case 8:{
                    setTextureRect(sf::IntRect(3500,0,500,1000));
                    break;
                }

                case 9:{
                    setTextureRect(sf::IntRect(4000,0,500,1000));
                    break;
                }

                case 0:{
                    setTextureRect(sf::IntRect(4500,0,500,1000));
                    break;
                }

                case -1:{
                    setTextureRect(sf::IntRect(5000,0,500,1000));
                    break;
                }

                case -2:{
                    setTextureRect(sf::IntRect(5000,1000,500,1000));
                    break;
                }
            }
        }else{
            switch(number){
                case 1:{
                    setTextureRect(sf::IntRect(0,1000,500,1000));
                    break;
                }

                case 2:{
                    setTextureRect(sf::IntRect(500,1000,500,1000));
                    break;
                }

                case 3:{
                    setTextureRect(sf::IntRect(1000,1000,500,1000));
                    break;
                }

                case 4:{
                    setTextureRect(sf::IntRect(1500,1000,500,1000));
                    break;
                }

                case 5:{
                    setTextureRect(sf::IntRect(2000,1000,500,1000));
                    break;
                }

                case 6:{
                    setTextureRect(sf::IntRect(2500,1000,500,1000));
                    break;
                }

                case 7:{
                    setTextureRect(sf::IntRect(3000,1000,500,1000));
                    break;
                }

                case 8:{
                    setTextureRect(sf::IntRect(3500,1000,500,1000));
                    break;
                }

                case 9:{
                    setTextureRect(sf::IntRect(4000,1000,500,1000));
                    break;
                }

                case 0:{
                    setTextureRect(sf::IntRect(4500,1000,500,1000));
                    break;
                }

                case -1:{
                    setTextureRect(sf::IntRect(5000,0,500,1000));
                    break;
                }

                case -2:{
                    setTextureRect(sf::IntRect(5000,1000,500,1000));
                    break;
                }
            }
        }
    }

};

class Brakes_heat: public sf::Sprite, sf::Texture{

public:

    Brakes_heat(sf::Vector2f position){
        setScale(10,0.5);
        setOrigin(0,0);
        setPosition(position);
    }

    ~Brakes_heat(){}

    void display_heat(float heat){
        int heat_int=heat*100;
        setTextureRect(sf::IntRect(heat_int,0,10,200));
    }
};

class Tires_heat: public sf::Sprite, sf::Texture{

public:

    Tires_heat(sf::Vector2f position){
        setScale(2,0.1);
        setOrigin(0,0);
        setPosition(position);
    }

    ~Tires_heat(){}

    void display_heat(float heat){
        int heat_int=heat*100;
        setTextureRect(sf::IntRect(heat_int,0,10,200));
    }
};

class Race_engineer: public sf::Sprite, sf::Texture{
private:
//virables

    bool displayed=false;
    int displayed_number=0;
    bool check_engine_said=false;
    bool are_tires_still_overheated=false;
    bool are_brakes_still_overheated=false;
    bool is_yellow_flag_still=false;
    bool is_red_flag_still=false;

public:
//constructor
    Race_engineer(sf::Vector2f position){
        setScale(0.1,0.1);
        setOrigin(0,0);
        setPosition(position);
        setTextureRect(sf::IntRect(0, 3000, 4000, 1000));
    }

    ~Race_engineer(){}

//methods
    void set_message(int message){
        switch(message){
            case 0:{
                setTextureRect(sf::IntRect(0, 3000, 4000, 1000));
                break;
            }

            case 1:{
                setTextureRect(sf::IntRect(0,0,4000,1000));
                break;
            }

            case 2:{
                setTextureRect(sf::IntRect(0,1000,4000,1000));
                break;
            }

            case 3:{
                setTextureRect(sf::IntRect(0,2000,4000,1000));
                break;
            }

            case 4:{
                setTextureRect(sf::IntRect(0,4000,4000,1000));
                break;
            }

            case 5:{
                setTextureRect(sf::IntRect(0,5000,4000,1000));
                break;
            }

            case 6:{
                setTextureRect(sf::IntRect(0,6000,4000,1000));
                break;
            }

        }
    }

    void set_displayed(bool status){displayed=status;}
    bool get_displayed(){return displayed;}

    void set_displayed_number(int number){displayed_number=number;}
    int get_displayed_number(){return displayed_number;}

    void set_check_engine_said(int status){check_engine_said=status;}
    bool get_check_engine_said(){return check_engine_said;}

    void set_are_tires_still_overheated(int status){are_tires_still_overheated=status;}
    bool get_are_tires_still_overheated(){return are_tires_still_overheated;}

    void set_are_brakes_still_overheated(int status){are_brakes_still_overheated=status;}
    bool get_are_brakes_still_overheated(){return are_brakes_still_overheated;}

    void set_is_yellow_flag_still(int status){is_yellow_flag_still=status;}
    bool get_is_yellow_flag_still(){return is_yellow_flag_still;}

    void set_is_red_flag_still(int status){is_red_flag_still=status;}
    bool get_is_red_flag_still(){return is_red_flag_still;}

};

class Flag: public sf::Sprite, sf::Texture{
private:
//virables
    int flag;
public:
//constructor
    Flag(sf::Vector2f position){
        setScale(0.1,0.1);
        setOrigin(0,0);
        setPosition(position);
        setTextureRect(sf::IntRect(0, 0, 1000, 1000));
    }

    ~Flag(){}

//mehtods
    void set_flag(){
        switch(flag){
            case 0:{
                setTextureRect(sf::IntRect(0, 0, 1000, 1000));
                break;
            }

            case 1:{
                setTextureRect(sf::IntRect(0,1000,1000,1000));
                break;
            }

            case 2:{
                setTextureRect(sf::IntRect(0,2000,1000,1000));
                break;
            }
        }
    }
    int get_flag(){return flag;}

    void flag_status(float speed, bool pitlane_detector, bool check_engine, sf::Clock &standing_time){
        sf::Time time=standing_time.getElapsedTime();
        if(speed>0){
            standing_time.restart();
            flag=0;
        }else{
            if(!pitlane_detector){
                if(time.asSeconds()>10){
                    flag=2;
                }
                if(check_engine && time.asSeconds()>20){
                    flag=1;
                }
            }
        }
        set_flag();
    }

};

#endif // HUD_H
