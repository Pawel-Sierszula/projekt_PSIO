#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <memory>
#include <math.h>
#include <vector>
#include <list>
#include <algorithm>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>

#include "functions.h"
#include "tor.h"
#include "car.h"
#include "barrier.h"
#include "hud.h"


void PRO(){
//VARIABLES
    float speed_scale;//=20;
    float braking_scale;//=1;
    float speed_decrease;//=0.0001;
    float friction_scale;//=1;
    float wheels_geometry;//=0.05;
    float throtle_scale;//=0.002;
    float engine_braking_scale;//=0.001;
    read_data(speed_scale,braking_scale,speed_decrease,friction_scale,wheels_geometry,throtle_scale,engine_braking_scale);

    bool hit=false;
    int hit_id;

    std::list<int> race_engineer_messages_list;

    double fps=0;
    sf::Vector2f car_movement;
    srand(time(NULL));

//OBJECTS

 //vectors
    std::vector<End_barrier> end_barrier;
    std::vector<Middle_barrier> mid_barrier;
    std::vector<Numbers> numbers;
    std::vector<Tires_heat> tires_heat;

 //main_objects
    Tor tor(sf::Vector2f(400,300));
    sf::Texture tor_texture;
    if (!tor_texture.loadFromFile("TOR.png")) {
        std::cerr << "Could not load texture" << std::endl;
    }
    tor.setTexture(tor_texture);

    Car car(sf::Vector2f (400,300));
    sf::Texture car_texture;
    if (!car_texture.loadFromFile("LMPcar.png")) {
        std::cerr << "Could not load texture" << std::endl;
    }
    car.setTexture(car_texture);
    car.set_speed_scale(speed_scale);
    car.set_braking_scale(braking_scale);
    car.set_speed_decrease(speed_decrease);
    car.set_friction_scale(friction_scale);
    car.set_wheels_geometry(wheels_geometry);
    car.set_throtle_scale(throtle_scale);
    car.set_engine_braking_scale(engine_braking_scale);

 //boxes
    Boxes boxes(sf::Vector2f(-1019,-319));
    sf::Texture boxes_texture;
    if (!boxes_texture.loadFromFile("boxes.png")) {
        std::cerr << "Could not load texture" << std::endl;
    }
    boxes.setTexture(boxes_texture);

 //barrier
    sf::Texture end_bar_texture;
    if (!end_bar_texture.loadFromFile("bariera_rbw_k_r130.png")) {
        std::cerr << "Could not load texture" << std::endl;
    }
    sf::Texture *end_bar_texture_p=&end_bar_texture;

    sf::Texture bar_1_texture;
    if (!bar_1_texture.loadFromFile("bariera_rbw_1.png")) {
        std::cerr << "Could not load texture" << std::endl;
    }
    sf::Texture *bar_1_texture_p=&bar_1_texture;

    sf::Texture bar_6_texture;
    bar_6_texture.setRepeated(true);
    if (!bar_6_texture.loadFromFile("bariera_rbw_6.png")) {
        std::cerr << "Could not load texture" << std::endl;
    }
    sf::Texture *bar_6_texture_p=&bar_6_texture;

    create_barriers(end_barrier,mid_barrier,end_bar_texture_p,bar_1_texture_p,bar_6_texture_p);

 //hud

    sf::Texture numbers_texture;
    numbers_texture.setRepeated(true);
    if (!numbers_texture.loadFromFile("numbers.png")) {
        std::cerr << "Could not load texture" << std::endl;
    }
    sf::Texture *numbers_texture_p=&numbers_texture;

    create_numbers(numbers,numbers_texture_p);

    sf::RectangleShape bottom_panel(sf::Vector2f(800,100));
    bottom_panel.setPosition(0,500);
    bottom_panel.setFillColor(sf::Color(50,50,50));
    bottom_panel.setOutlineColor(sf::Color(100,100,100));
    bottom_panel.setOutlineThickness(5);

    sf::RectangleShape top_panel(sf::Vector2f(800,100));
    top_panel.setPosition(0,0);
    top_panel.setFillColor(sf::Color(0,0,0));
    top_panel.setOutlineColor(sf::Color(100,100,100));
    top_panel.setOutlineThickness(5);

    Hud bottom_hud(sf::Vector2f (0,500));
    sf::Texture bottom_hud_texture;
    if (!bottom_hud_texture.loadFromFile("bottom_hud.png")) {
        std::cerr << "Could not load texture" << std::endl;
    }
    bottom_hud.setTexture(bottom_hud_texture);

    Hud top_hud(sf::Vector2f (0,0));
    sf::Texture top_hud_texture;
    if (!top_hud_texture.loadFromFile("top_hud.png")) {
        std::cerr << "Could not load texture" << std::endl;
    }
    top_hud.setTexture(top_hud_texture);

    Gears gear(sf::Vector2f (247,530));
    sf::Texture gear_texture;
    if (!gear_texture.loadFromFile("gears.png")) {
        std::cerr << "Could not load texture" << std::endl;
    }
    gear.setTexture(gear_texture);

    Rpm rpm(sf::Vector2f (20,500));
    sf::Texture rpm_texture;
    if (!rpm_texture.loadFromFile("rpm.png")) {
        std::cerr << "Could not load texture" << std::endl;
    }
    rpm.setTexture(rpm_texture);

    Check_engine check_engine(sf::Vector2f (693,500));
    sf::Texture check_engine_texture;
    if (!check_engine_texture.loadFromFile("check_engine.png")) {
        std::cerr << "Could not load texture" << std::endl;
    }
    check_engine.setTexture(check_engine_texture);

    Engine_and_downshift engine_and_downshift(sf::Vector2f (20,530));
    sf::Texture engine_and_downshift_texture;
    if (!engine_and_downshift_texture.loadFromFile("engine_and_downshift.png")) {
        std::cerr << "Could not load texture" << std::endl;
    }
    engine_and_downshift.setTexture(engine_and_downshift_texture);

    Brakes_heat brakes_heat(sf::Vector2f (460,500));
    sf::Texture heat_texture;
    //heat_texture.setRepeated(true);
    if (!heat_texture.loadFromFile("heat.png")) {
        std::cerr << "Could not load texture" << std::endl;
    }
    brakes_heat.setTexture(heat_texture);

    sf::Texture *heat_texture_p=&heat_texture;
    create_hud_tires(tires_heat,heat_texture_p);

    Race_engineer race_engineer(sf::Vector2f(260,0));
    sf::Texture race_engineer_texture;
    if (!race_engineer_texture.loadFromFile("race_engineer.png")) {
        std::cerr << "Could not load texture" << std::endl;
    }
    race_engineer.setTexture(race_engineer_texture);

    Flag flag(sf::Vector2f (693,0));
    sf::Texture flag_texture;
    if (!flag_texture.loadFromFile("flag.png")) {
        std::cerr << "Could not load texture" << std::endl;
    }
    flag.setTexture(flag_texture);

//WINDOW_CREATED

    sf::RenderWindow window(sf::VideoMode(800, 600), "Time Attack");
    sf::Clock clock;
    sf::Clock counting_time;
    sf::Clock message_time;
    sf::Clock standing_time;

//WINDOW_OPEN

    while (window.isOpen()) {

        clock.restart();

 //EVENTS

        sf::Event event;
        while (window.pollEvent(event)) {
            // "close requested" event: we close the window
            if (event.type == sf::Event::Closed){
                window.close();
                std::cout<<"closed"<<std::endl;
            }

  //released_key

            if (event.type == sf::Event::KeyReleased) {

                if (event.key.code == sf::Keyboard::Up) {
                    car.gas_pressed(false);
                    //std::cout << "Up released" << std::endl;
                }

                if (event.key.code == sf::Keyboard::Down) {
                    car.brake_pressed(false);
                    //std::cout << "Down released" << std::endl;
                }

                if (event.key.code == sf::Keyboard::Left) {
                    car.left_pressed(false);
                    //std::cout << "Left released" << std::endl;
                }

                if (event.key.code == sf::Keyboard::Right) {
                    car.right_pressed(false);
                    //std::cout << "Right released" << std::endl;
                }

                if (event.key.code == sf::Keyboard::LShift) {
                    car.gearbox(1);
                    //std::cout << "Left_Shift released" << std::endl;
                }

                if (event.key.code == sf::Keyboard::LControl) {
                    car.gearbox(-1);
                    //std::cout << "Left_Ctrl released" << std::endl;
                }

                if (event.key.code == sf::Keyboard::Tab) {
                    if(car.engine_on_off_status()==false){
                        if(car.get_gear()==0){
                            car.engine_switch(true);
                        }
                    }else{
                        car.engine_switch(false);
                    }
                    //std::cout << "Tab released" << std::endl;
                }
            }

  //pushed_key

            if(sf::Keyboard::isKeyPressed(sf::Keyboard::Up)) {
                car.gas_pressed(true);
                //std::cout << "Up key is pressed" << std::endl;
            }

            if(sf::Keyboard::isKeyPressed(sf::Keyboard::Down)) {
                car.brake_pressed(true);
                //std::cout << "Down key is pressed" << std::endl;
            }

            if(sf::Keyboard::isKeyPressed(sf::Keyboard::Left)) {
                car.left_pressed(true);
                //std::cout << "Left key is pressed" << std::endl;
            }

            if(sf::Keyboard::isKeyPressed(sf::Keyboard::Right)) {
                car.right_pressed(true);
                //std::cout << "Right key is pressed" << std::endl;
            }

        }

  //operations

   //_game

        //__move_car
        car_movement=car.car_movement();
        tor.move_camera(car_movement);
        boxes.move_camera(car_movement);
        for(size_t i=0; i<end_barrier.size(); i++){
            end_barrier[i].move_camera(car_movement);
        }
        for(size_t i=0; i<mid_barrier.size(); i++){
            mid_barrier[i].move_camera(car_movement);
        }
        car.pitlane_speed(tor.pitlane_detection(car));

        //__find_if_car_hit_the_barrier
        hit=false;
        if(boxes.hit(car)){hit=true; hit_id=0;}
        for(size_t i=0; i<end_barrier.size(); i++){
            if(end_barrier[i].hit(car)){hit=true; hit_id=i;}
            if(mid_barrier[i].hit(car)){hit=true; hit_id=i;}
        }

        //__stop_car_while_hit
        if(hit==true){
            for(size_t i=0; i<end_barrier.size(); i++){
                end_barrier[i].move_camera(-car_movement);
            }
            for(size_t i=0; i<mid_barrier.size(); i++){
                mid_barrier[i].move_camera(-car_movement);
            }
            tor.move_camera(-car_movement);
            car.reverse_rotate();
            car.reset_speed();
            if(front_hit(mid_barrier[hit_id].getRotation(),car.getRotation())){
                if(car.get_gear()!=0 && car.engine_rpm(rpm.get_max_rpm())==0){car.engine_switch(false);}
            }
        }

        //__track_limits
        tor.track_limits(car);
        car.is_FL_off(tor.get_FL_wheel_position());
        car.is_FR_off(tor.get_FR_wheel_position());
        car.is_RL_off(tor.get_RL_wheel_position());
        car.is_RR_off(tor.get_RR_wheel_position());

        //__tires_heatup
        car.wheels_heat_balance();

        //__time_mesurement
        time_mesurement(numbers,counting_time,tor,car);

   //_hud

        gear.set_gear(car.get_gear());
        rpm.animate_rpm(car.engine_rpm(rpm.get_max_rpm()));
        check_engine.status(car.check_engine_status());
        engine_and_downshift.status(car.engine_on_off_status(),car.safe_downshift(),car.check_engine_status());
        speedometer_animation(numbers,car);
        brakes_heat.display_heat(car.get_brakes_heat());
        tires_heat[0].display_heat(car.get_FL_heat());
        tires_heat[1].display_heat(car.get_FR_heat());
        tires_heat[2].display_heat(car.get_RL_heat());
        tires_heat[3].display_heat(car.get_RR_heat());
        race_engineer_messages(race_engineer,tor,car,flag,message_time,race_engineer_messages_list);
        flag.flag_status(car.get_speed(),tor.pitlane_detection(car),car.check_engine_status(),standing_time);


 //CLEAR

        window.clear(sf::Color::Blue);

 //DRAW
  //game
        window.draw(tor);
        window.draw(boxes);
        for(size_t i=0; i<end_barrier.size(); i++){
            window.draw(end_barrier[i]);
        }
        for(size_t i=0; i<mid_barrier.size(); i++){
            window.draw(mid_barrier[i]);
        }
        window.draw(car);



  //hud
        //bottom
        window.draw(bottom_panel);
        window.draw(rpm);
        window.draw(brakes_heat);
        for(size_t i=0; i<tires_heat.size(); i++){
            window.draw(tires_heat[i]);
        }
        window.draw(bottom_hud);
        window.draw(gear);
        window.draw(check_engine);
        window.draw(engine_and_downshift);


        //top
        window.draw(top_panel);
        window.draw(top_hud);
        for(size_t i=0; i<numbers.size(); i++){
            window.draw(numbers[i]);
        }
        window.draw(race_engineer);
        window.draw(flag);

 //DISPLAY

        window.display();

        sf::Time time1 = clock.getElapsedTime();

        fps=(1/time1.Time::asSeconds());

    }

    //std::cout<<"predkosc rysowania: "<<fps<<" fps"<<std::endl;
}

int main() {
    PRO();
    return 0;
}
