#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <memory>
#include <math.h>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>

#include "tor.h"
#include "car.h"
#include "functions.h"

void PRO(){
//VARIABLES
    double fps=0;
    sf::Vector2f car_movement;
    srand(time(NULL));


    Tor tor(sf::Vector2f(400,300));
    sf::Texture tor_texture;
    if (!tor_texture.loadFromFile("TOR.png")) {
        std::cerr << "Could not load texture" << std::endl;
    }
    tor.setTexture(tor_texture);

    Car car(sf::Vector2f (400,300));
    sf::Texture car_texture;
    if (!car_texture.loadFromFile("LMPcar.png")) {
        std::cerr << "Could not load texture" << std::endl;
    }
    car.setTexture(car_texture);


//WINDOW_CREATED

    sf::RenderWindow window(sf::VideoMode(800, 600), "Time Attack");
    sf::Clock clock;


//WINDOW_OPEN

    while (window.isOpen()) {

        clock.restart();

 //EVENTS

        sf::Event event;
        while (window.pollEvent(event)) {
            // "close requested" event: we close the window
            if (event.type == sf::Event::Closed){
                window.close();
                std::cout<<"closed"<<std::endl;
            }

  //released_key

            if (event.type == sf::Event::KeyReleased) {

                if (event.key.code == sf::Keyboard::Up) {
                    car.gas_pressed(false);
                    //std::cout << "Up released" << std::endl;
                }

                if (event.key.code == sf::Keyboard::Down) {
                    car.brake_pressed(false);
                    //std::cout << "Down released" << std::endl;
                }

                if (event.key.code == sf::Keyboard::Left) {
                    car.left_pressed(false);
                    //std::cout << "Left released" << std::endl;
                }

                if (event.key.code == sf::Keyboard::Right) {
                    car.right_pressed(false);
                    //std::cout << "Right released" << std::endl;
                }


            }

  //pushed_key

            if(sf::Keyboard::isKeyPressed(sf::Keyboard::Up)) {
                car.gas_pressed(true);
                //std::cout << "Up key is pressed" << std::endl;
            }

            if(sf::Keyboard::isKeyPressed(sf::Keyboard::Down)) {
                car.brake_pressed(true);
                //std::cout << "Down key is pressed" << std::endl;
            }

            if(sf::Keyboard::isKeyPressed(sf::Keyboard::Left)) {
                car.left_pressed(true);
                //std::cout << "Left key is pressed" << std::endl;
            }

            if(sf::Keyboard::isKeyPressed(sf::Keyboard::Right)) {
                car.right_pressed(true);
                //std::cout << "Right key is pressed" << std::endl;
            }


        }

  //operations

        car_movement=car.car_movement();
        tor.move_camera(car_movement);

 //CLEAR

        window.clear(sf::Color::Blue);

 //DRAW

        window.draw(tor);
        window.draw(car);

 //DISPLAY

        window.display();

        sf::Time time1 = clock.getElapsedTime();

        fps=(1/time1.Time::asSeconds());

    }

    std::cout<<"predkosc rysowania: "<<fps<<" fps"<<std::endl;

}

int main() {
    PRO();
    return 0;
}
