#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <memory>
#include <math.h>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>


#ifndef TOR_H
#define TOR_H

class Tor: public sf::Sprite, sf::Texture{

public:

    Tor(sf::Vector2f position){
        setScale(1,1);
        setOrigin(3000,3000);
        setPosition(position);
    }

    void move_camera(sf::Vector2f movement){
        move(movement);
    }

    ~Tor(){}
};

#endif // TOR_H
