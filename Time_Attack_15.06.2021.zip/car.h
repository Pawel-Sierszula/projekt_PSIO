#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <memory>
#include <math.h>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>

#ifndef CAR_H
#define CAR_H

class Car: public sf::Sprite, sf::Texture{
private:
//variables

    bool gas_pedal=false;
    bool brake_pedal=false;
    bool left_steering=false;
    bool right_steering=false;

    int   gear=0, last_gear=0;
    float acceleration=0;
    float speed=0;

public:    
//construktor

    Car(sf::Vector2f position){
        setScale(0.1, 0.1);
        //setOrigin(412,792.5);
        setOrigin(412,1060);
        setPosition(position);
    }


    ~Car(){}

//metods

    void gas_pressed   (bool up)    {gas_pedal=up;}
    void brake_pressed (bool down)  {brake_pedal=down;}
    void left_pressed  (bool left)  {left_steering=left;}
    void right_pressed (bool right) {right_steering=right;}

    void car_size(double &high, double &width ){
        high=1585;
        width=824;
    }

    sf::Vector2f car_movement(){
        float angle, rad, pi=3.14159265359, x=0, y=0;

        if(gas_pedal ){
            if(acceleration==0){
                if(speed>0){speed=speed-0.00001;}
            }else{
                if(speed<0.1){speed=speed+acceleration;}
            }
        }else{
            if(brake_pedal){
                if(speed>0){speed=speed-0.00001;}
                if(speed>0){speed=speed-0.00001;}
            }else{
                if(speed>0){speed=speed-0.000005;}
            }
        }

        if(speed>0){
            if(left_steering){
                if(right_steering){rotate(0);}else{rotate(-0.01);}
            }else{
                if(right_steering){rotate(0.01);}
            }
        }
        angle=0;
        angle=getRotation();
        rad=angle*pi/180;

        y=speed*cos(rad);
        x=speed*(-sin(rad));

        if(gear<0 || last_gear<0){
            x=-x;
            y=-y;
        }
        if(speed>0){
            return sf::Vector2f(x,y);
        }else{
            if(speed<0){
                return sf::Vector2f(-x,-y);
            }else{
                return sf::Vector2f(0,0);
            }
        }

    }

    void reverse_rotate(){
        if(speed>0){
            if(left_steering){
                if(right_steering){rotate(0);}else{rotate(0.01);}
            }else{
                if(right_steering){rotate(-0.01);}
            }
        }
    }
    void reset_speed(){speed=0;}

    void gearbox(int shift){
        if(gear<1 && shift>0 && !(speed>0 && last_gear==-1)){
            last_gear=gear;
            gear=gear+shift;
        }
        if(gear>-1 && shift<0 && !(speed>0 && last_gear==1)){
            last_gear=gear;
            gear=gear+shift;
        }
        //std::cout<<gear<<std::endl;

        if(gear==0){
            acceleration=0;
        }else{


            acceleration=0.00001;
        }
    }
    int get_gear(){return gear;}

};

#endif // CAR_H
