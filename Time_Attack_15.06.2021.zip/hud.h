#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <memory>
#include <math.h>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>


#ifndef HUD_H
#define HUD_H

class Hud: public sf::Sprite, sf::Texture{

public:

    Hud(sf::Vector2f position){
        setScale(0.1,0.1);
        setOrigin(0,0);
        setPosition(position);
    }

    ~Hud(){}
};

class Rpm: public sf::Sprite, sf::Texture{
private:
    double rpm_volume=0;
    bool gas_pedal=false;

public:

    Rpm(sf::Vector2f position){
        setScale(0.1,1);
        setOrigin(0,0);
        setPosition(position);
    }

    ~Rpm(){}

    void gas_pressed(bool up){gas_pedal=up;}

    void animate_rpm(){
        if(gas_pedal){
            if(rpm_volume<1900){rpm_volume=rpm_volume+0.00000000001;}
        }else{
            if(rpm_volume>0){rpm_volume=rpm_volume-0.00000000001;}
        }
        setTextureRect(sf::IntRect(0,0,rpm_volume,100));
    }
};

class Gears: public sf::Sprite, sf::Texture{

public:

    Gears(sf::Vector2f position){
        setScale(0.05,0.05);
        setOrigin(0,0);
        setPosition(position);
    }

    ~Gears(){}

    void set_gear(int gear){
        switch(gear){
            case -1:{
                setTextureRect(sf::IntRect(0, 0, 1000, 1000));
                break;
            }

            case 0:{
                setTextureRect(sf::IntRect(1000,0,1000,1000));
                break;
            }

            case 1:{
                setTextureRect(sf::IntRect(2000,0,1000,1000));
                break;
            }

            case 2:{
                setTextureRect(sf::IntRect(3000,0,1000,1000));
                break;
            }

            case 3:{
                setTextureRect(sf::IntRect(4000,0,1000,1000));
                break;
            }

            case 4:{
                setTextureRect(sf::IntRect(5000,0,1000,1000));
                break;
            }

            case 5:{
                setTextureRect(sf::IntRect(6000,0,1000,1000));
                break;
            }
        }
    }

};

#endif // HUD_H
