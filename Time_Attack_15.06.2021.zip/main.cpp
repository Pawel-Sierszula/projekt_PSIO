#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <memory>
#include <math.h>
#include <vector>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>

#include "functions.h"
#include "tor.h"
#include "car.h"
#include "barrier.h"
#include "hud.h"


void PRO(){
//VARIABLES
    bool hit=false;
    double fps=0;
    sf::Vector2f car_movement;
    std::vector<End_barrier> end_barrier;
    std::vector<Middle_barrier> mid_barrier;
    srand(time(NULL));

//OBJECTS

    Tor tor(sf::Vector2f(400,300));
    sf::Texture tor_texture;
    if (!tor_texture.loadFromFile("TOR.png")) {
        std::cerr << "Could not load texture" << std::endl;
    }
    tor.setTexture(tor_texture);

    Car car(sf::Vector2f (400,300));
    sf::Texture car_texture;
    if (!car_texture.loadFromFile("LMPcar.png")) {
        std::cerr << "Could not load texture" << std::endl;
    }
    car.setTexture(car_texture);

 //barrier
    sf::Texture end_bar_texture;
    if (!end_bar_texture.loadFromFile("bariera_rbw_k_r130.png")) {
        std::cerr << "Could not load texture" << std::endl;
    }
    sf::Texture *end_bar_texture_p=&end_bar_texture;

    sf::Texture bar_1_texture;
    if (!bar_1_texture.loadFromFile("bariera_rbw_1.png")) {
        std::cerr << "Could not load texture" << std::endl;
    }
    sf::Texture *bar_1_texture_p=&bar_1_texture;

    sf::Texture bar_6_texture;
    bar_6_texture.setRepeated(true);
    if (!bar_6_texture.loadFromFile("bariera_rbw_6.png")) {
        std::cerr << "Could not load texture" << std::endl;
    }
    sf::Texture *bar_6_texture_p=&bar_6_texture;

    create_barriers(end_barrier,mid_barrier,end_bar_texture_p,bar_1_texture_p,bar_6_texture_p);

 //hud
    sf::RectangleShape bottom_panel(sf::Vector2f(800,100));
    bottom_panel.setPosition(0,500);
    bottom_panel.setFillColor(sf::Color(50,50,50));
    bottom_panel.setOutlineColor(sf::Color(100,100,100));
    bottom_panel.setOutlineThickness(5);

    sf::RectangleShape top_panel(sf::Vector2f(800,100));
    top_panel.setPosition(0,0);
    top_panel.setFillColor(sf::Color(0,0,0));
    top_panel.setOutlineColor(sf::Color(100,100,100));
    top_panel.setOutlineThickness(5);

    Hud bottom_hud(sf::Vector2f (0,500));
    sf::Texture bottom_hud_texture;
    if (!bottom_hud_texture.loadFromFile("bottom_hud.png")) {
        std::cerr << "Could not load texture" << std::endl;
    }
    bottom_hud.setTexture(bottom_hud_texture);

    Gears gear(sf::Vector2f (247,530));
    sf::Texture gear_texture;
    if (!gear_texture.loadFromFile("gears.png")) {
        std::cerr << "Could not load texture" << std::endl;
    }
    gear.setTexture(gear_texture);

    Rpm rpm(sf::Vector2f (20,500));
    sf::Texture rpm_texture;
    rpm_texture.setRepeated(true);
    if (!rpm_texture.loadFromFile("rpm.png")) {
        std::cerr << "Could not load texture" << std::endl;
    }
    rpm.setTexture(rpm_texture);



//WINDOW_CREATED

    sf::RenderWindow window(sf::VideoMode(800, 600), "Time Attack");
    sf::Clock clock;


//WINDOW_OPEN

    while (window.isOpen()) {

        clock.restart();

 //EVENTS

        sf::Event event;
        while (window.pollEvent(event)) {
            // "close requested" event: we close the window
            if (event.type == sf::Event::Closed){
                window.close();
                std::cout<<"closed"<<std::endl;
            }

  //released_key

            if (event.type == sf::Event::KeyReleased) {

                if (event.key.code == sf::Keyboard::Up) {
                    car.gas_pressed(false);
                    rpm.gas_pressed(false);
                    //std::cout << "Up released" << std::endl;
                }

                if (event.key.code == sf::Keyboard::Down) {
                    car.brake_pressed(false);
                    //std::cout << "Down released" << std::endl;
                }

                if (event.key.code == sf::Keyboard::Left) {
                    car.left_pressed(false);
                    //std::cout << "Left released" << std::endl;
                }

                if (event.key.code == sf::Keyboard::Right) {
                    car.right_pressed(false);
                    //std::cout << "Right released" << std::endl;
                }

                if (event.key.code == sf::Keyboard::LShift) {
                    car.gearbox(1);
                    //std::cout << "Left_Shift released" << std::endl;
                }

                if (event.key.code == sf::Keyboard::LControl) {
                    car.gearbox(-1);
                    //std::cout << "Left_Ctrl released" << std::endl;
                }


            }

  //pushed_key

            if(sf::Keyboard::isKeyPressed(sf::Keyboard::Up)) {
                car.gas_pressed(true);
                rpm.gas_pressed(true);
                //std::cout << "Up key is pressed" << std::endl;
            }

            if(sf::Keyboard::isKeyPressed(sf::Keyboard::Down)) {
                car.brake_pressed(true);
                //std::cout << "Down key is pressed" << std::endl;
            }

            if(sf::Keyboard::isKeyPressed(sf::Keyboard::Left)) {
                car.left_pressed(true);
                //std::cout << "Left key is pressed" << std::endl;
            }

            if(sf::Keyboard::isKeyPressed(sf::Keyboard::Right)) {
                car.right_pressed(true);
                //std::cout << "Right key is pressed" << std::endl;
            }


        }

  //operations

   //_game

        car_movement=car.car_movement();
        tor.move_camera(car_movement);
        for(size_t i=0; i<end_barrier.size(); i++){
            end_barrier[i].move_camera(car_movement);
        }
        for(size_t i=0; i<mid_barrier.size(); i++){
            mid_barrier[i].move_camera(car_movement);
        }

        hit=false;
        for(size_t i=0; i<end_barrier.size(); i++){
            if(end_barrier[i].hit(car)){hit=true;}
            if(mid_barrier[i].hit(car)){hit=true;}
        }

        if(hit==true){
            for(size_t i=0; i<end_barrier.size(); i++){
                end_barrier[i].move_camera(-car_movement);
            }
            for(size_t i=0; i<mid_barrier.size(); i++){
                mid_barrier[i].move_camera(-car_movement);
            }
            tor.move_camera(-car_movement);
            car.reverse_rotate();
            car.reset_speed();
        }

   //_hud

        gear.set_gear(car.get_gear());
        rpm.animate_rpm();

 //CLEAR

        window.clear(sf::Color::Blue);

 //DRAW

  //game
        window.draw(tor);
        for(size_t i=0; i<end_barrier.size(); i++){
            window.draw(end_barrier[i]);
        }
        for(size_t i=0; i<mid_barrier.size(); i++){
            window.draw(mid_barrier[i]);
        }
        window.draw(car);



  //hud
        window.draw(bottom_panel);
        window.draw(top_panel);
        window.draw(rpm);
        window.draw(bottom_hud);
        window.draw(gear);


 //DISPLAY

        window.display();

        sf::Time time1 = clock.getElapsedTime();

        fps=(1/time1.Time::asSeconds());

    }

    std::cout<<"predkosc rysowania: "<<fps<<" fps"<<std::endl;

}

int main() {
    PRO();
    return 0;
}
