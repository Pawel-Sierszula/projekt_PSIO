#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <memory>
#include <math.h>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>

#include "tor.h"
#include "car.h"
#include "barrier.h"

#ifndef FUNCTIONS_H
#define FUNCTIONS_H

//____CREATE_BARRIERS____

void create_barriers(std::vector<End_barrier> &end_barrier ,std::vector<Middle_barrier> &mid_barrier, sf::Texture *end_bar_texture_p, sf::Texture *bar_1_texture_p, sf::Texture *bar_6_texture_p){

    //1
    end_barrier.emplace_back(End_barrier(sf::Vector2f (750,-590)));
    end_barrier[0].setTexture(*end_bar_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (750,-590)));
    mid_barrier[0].setTexture(*bar_1_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (750,-575)));
    mid_barrier[1].setTextureRect(sf::IntRect(0, 0, 260, 18900));
    mid_barrier[1].setTexture(*bar_6_texture_p);

    end_barrier.emplace_back(End_barrier(sf::Vector2f (750,1315)));
    end_barrier[1].setTexture(*end_bar_texture_p);
    end_barrier[1].setRotation(180);

    //2
    end_barrier.emplace_back(End_barrier(sf::Vector2f (750,-620)));
    end_barrier[2].setRotation(150);
    end_barrier[2].setTexture(*end_bar_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (750,-620)));
    mid_barrier[2].setRotation(150);
    mid_barrier[2].setTexture(*bar_1_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (742.5,-633)));
    mid_barrier[3].setRotation(150);
    mid_barrier[3].setTextureRect(sf::IntRect(0, 0, 260, 3600));
    mid_barrier[3].setTexture(*bar_6_texture_p);

    end_barrier.emplace_back(End_barrier(sf::Vector2f (562.5,-945)));
    end_barrier[3].setRotation(330);
    end_barrier[3].setTexture(*end_bar_texture_p);

    //3
    end_barrier.emplace_back(End_barrier(sf::Vector2f (542.5,-965)));
    end_barrier[4].setRotation(120);
    end_barrier[4].setTexture(*end_bar_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (542.5,-965)));
    mid_barrier[4].setRotation(120);
    mid_barrier[4].setTexture(*bar_1_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (529.5,-972.5)));
    mid_barrier[5].setRotation(120);
    mid_barrier[5].setTextureRect(sf::IntRect(0, 0, 260, 2700));
    mid_barrier[5].setTexture(*bar_6_texture_p);

    end_barrier.emplace_back(End_barrier(sf::Vector2f (295.5,-1107.5)));
    end_barrier[5].setRotation(300);
    end_barrier[5].setTexture(*end_bar_texture_p);

    //4
    end_barrier.emplace_back(End_barrier(sf::Vector2f (265,-1110)));
    end_barrier[6].setRotation(90);
    end_barrier[6].setTexture(*end_bar_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (265,-1110)));
    mid_barrier[6].setRotation(90);
    mid_barrier[6].setTexture(*bar_1_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (250,-1110)));
    mid_barrier[7].setRotation(90);
    mid_barrier[7].setTextureRect(sf::IntRect(0, 0, 260, 9000));
    mid_barrier[7].setTexture(*bar_6_texture_p);

    end_barrier.emplace_back(End_barrier(sf::Vector2f (-650,-1110)));
    end_barrier[7].setRotation(270);
    end_barrier[7].setTexture(*end_bar_texture_p);

    //5
    end_barrier.emplace_back(End_barrier(sf::Vector2f (800,400)));
    end_barrier[8].setRotation(270);
    end_barrier[8].setTexture(*end_bar_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (800,400)));
    mid_barrier[8].setRotation(270);
    mid_barrier[8].setTexture(*bar_1_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (815,400)));
    mid_barrier[9].setRotation(270);
    mid_barrier[9].setTextureRect(sf::IntRect(0, 0, 260, 7200));
    mid_barrier[9].setTexture(*bar_6_texture_p);

    end_barrier.emplace_back(End_barrier(sf::Vector2f (1535,400)));
    end_barrier[9].setRotation(90);
    end_barrier[9].setTexture(*end_bar_texture_p);

    //6
    end_barrier.emplace_back(End_barrier(sf::Vector2f (1535,430)));
    end_barrier[10].setRotation(0);
    end_barrier[10].setTexture(*end_bar_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (1535,430)));
    mid_barrier[10].setRotation(0);
    mid_barrier[10].setTexture(*bar_1_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (1535,445)));
    mid_barrier[11].setRotation(0);
    mid_barrier[11].setTextureRect(sf::IntRect(0, 0, 260, 1200));
    mid_barrier[11].setTexture(*bar_6_texture_p);

    end_barrier.emplace_back(End_barrier(sf::Vector2f (1535,565)));
    end_barrier[11].setRotation(180);
    end_barrier[11].setTexture(*end_bar_texture_p);

    //7
    end_barrier.emplace_back(End_barrier(sf::Vector2f (1535,595)));
    end_barrier[12].setRotation(45);
    end_barrier[12].setTexture(*end_bar_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (1535,595)));
    mid_barrier[12].setRotation(45);
    mid_barrier[12].setTexture(*bar_1_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (1524.4,605.6)));
    mid_barrier[13].setRotation(45);
    mid_barrier[13].setTextureRect(sf::IntRect(0, 0, 260, 17700));
    mid_barrier[13].setTexture(*bar_6_texture_p);

    end_barrier.emplace_back(End_barrier(sf::Vector2f (272.8,1857)));
    end_barrier[13].setRotation(225);
    end_barrier[13].setTexture(*end_bar_texture_p);

    //8
    end_barrier.emplace_back(End_barrier(sf::Vector2f (240,1857)));
    end_barrier[14].setRotation(135);
    end_barrier[14].setTexture(*end_bar_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (240,1857)));
    mid_barrier[14].setRotation(135);
    mid_barrier[14].setTexture(*bar_1_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (229.4,1846.4)));
    mid_barrier[15].setRotation(135);
    mid_barrier[15].setTextureRect(sf::IntRect(0, 0, 260, 3600));
    mid_barrier[15].setTexture(*bar_6_texture_p);

    end_barrier.emplace_back(End_barrier(sf::Vector2f (-25,1592)));
    end_barrier[15].setRotation(315);
    end_barrier[15].setTexture(*end_bar_texture_p);

    //9
    end_barrier.emplace_back(End_barrier(sf::Vector2f (50,-350)));
    end_barrier[16].setRotation(0);
    end_barrier[16].setTexture(*end_bar_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (50,-350)));
    mid_barrier[16].setRotation(0);
    mid_barrier[16].setTexture(*bar_1_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (50,-335)));
    mid_barrier[17].setRotation(0);
    mid_barrier[17].setTextureRect(sf::IntRect(0, 0, 260, 12600));
    mid_barrier[17].setTexture(*bar_6_texture_p);

    end_barrier.emplace_back(End_barrier(sf::Vector2f (50,925)));
    end_barrier[17].setRotation(180);
    end_barrier[17].setTexture(*end_bar_texture_p);

    //10                                                                <--possible_pit_stop_exit
    end_barrier.emplace_back(End_barrier(sf::Vector2f (-1500,-350)));
    end_barrier[18].setRotation(270);
    end_barrier[18].setTexture(*end_bar_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (-1500,-350)));
    mid_barrier[18].setRotation(270);
    mid_barrier[18].setTexture(*bar_1_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (-1485,-350)));
    mid_barrier[19].setRotation(270);
    mid_barrier[19].setTextureRect(sf::IntRect(0, 0, 260, 9000));
    mid_barrier[19].setTexture(*bar_6_texture_p);

    end_barrier.emplace_back(End_barrier(sf::Vector2f (-585,-350)));
    end_barrier[19].setRotation(90);
    end_barrier[19].setTexture(*end_bar_texture_p);

    //11
    end_barrier.emplace_back(End_barrier(sf::Vector2f (-1500,-380)));
    end_barrier[20].setRotation(180);
    end_barrier[20].setTexture(*end_bar_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (-1500,-380)));
    mid_barrier[20].setRotation(180);
    mid_barrier[20].setTexture(*bar_1_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (-1500,-395)));
    mid_barrier[21].setRotation(180);
    mid_barrier[21].setTextureRect(sf::IntRect(0, 0, 260, 13500));
    mid_barrier[21].setTexture(*bar_6_texture_p);

    end_barrier.emplace_back(End_barrier(sf::Vector2f (-1500,-1745)));
    end_barrier[21].setRotation(0);
    end_barrier[21].setTexture(*end_bar_texture_p);

    //12
    end_barrier.emplace_back(End_barrier(sf::Vector2f (-1500,-1780)));
    end_barrier[22].setRotation(270);
    end_barrier[22].setTexture(*end_bar_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (-1500,-1780)));
    mid_barrier[22].setRotation(270);
    mid_barrier[22].setTexture(*bar_1_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (-1485,-1780)));
    mid_barrier[23].setRotation(270);
    mid_barrier[23].setTextureRect(sf::IntRect(0, 0, 260, 22500));
    mid_barrier[23].setTexture(*bar_6_texture_p);

    end_barrier.emplace_back(End_barrier(sf::Vector2f (765,-1780)));
    end_barrier[23].setRotation(90);
    end_barrier[23].setTexture(*end_bar_texture_p);

    //13
    end_barrier.emplace_back(End_barrier(sf::Vector2f (795,-1750)));
    end_barrier[24].setRotation(315);
    end_barrier[24].setTexture(*end_bar_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (795,-1750)));
    mid_barrier[24].setRotation(315);
    mid_barrier[24].setTexture(*bar_1_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (805.6,-1739.4)));
    mid_barrier[25].setRotation(315);
    mid_barrier[25].setTextureRect(sf::IntRect(0, 0, 260, 20100));
    mid_barrier[25].setTexture(*bar_6_texture_p);

    end_barrier.emplace_back(End_barrier(sf::Vector2f (2226.9,-318.1)));
    end_barrier[25].setRotation(135);
    end_barrier[25].setTexture(*end_bar_texture_p);

    //14
    end_barrier.emplace_back(End_barrier(sf::Vector2f (2227,-290)));
    end_barrier[26].setRotation(0);
    end_barrier[26].setTexture(*end_bar_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (2227,-290)));
    mid_barrier[26].setRotation(0);
    mid_barrier[26].setTexture(*bar_1_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (2227,-275)));
    mid_barrier[27].setRotation(0);
    mid_barrier[27].setTextureRect(sf::IntRect(0, 0, 260, 11400));
    mid_barrier[27].setTexture(*bar_6_texture_p);

    end_barrier.emplace_back(End_barrier(sf::Vector2f (2227,865)));
    end_barrier[27].setRotation(180);
    end_barrier[27].setTexture(*end_bar_texture_p);

    //15
    end_barrier.emplace_back(End_barrier(sf::Vector2f (2207,885)));
    end_barrier[28].setRotation(45);
    end_barrier[28].setTexture(*end_bar_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (2207,885)));
    mid_barrier[28].setRotation(45);
    mid_barrier[28].setTexture(*bar_1_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (2196.4,895.6)));
    mid_barrier[29].setRotation(45);
    mid_barrier[29].setTextureRect(sf::IntRect(0, 0, 260, 27000));
    mid_barrier[29].setTexture(*bar_6_texture_p);

    end_barrier.emplace_back(End_barrier(sf::Vector2f (287.2,2804.8)));
    end_barrier[29].setRotation(225);
    end_barrier[29].setTexture(*end_bar_texture_p);

    //16
    end_barrier.emplace_back(End_barrier(sf::Vector2f (257,2805)));
    end_barrier[30].setRotation(90);
    end_barrier[30].setTexture(*end_bar_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (257,2805)));
    mid_barrier[30].setRotation(90);
    mid_barrier[30].setTexture(*bar_1_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (242,2805)));
    mid_barrier[31].setRotation(90);
    mid_barrier[31].setTextureRect(sf::IntRect(0, 0, 260, 2700));
    mid_barrier[31].setTexture(*bar_6_texture_p);

    end_barrier.emplace_back(End_barrier(sf::Vector2f (-28,2805)));
    end_barrier[31].setRotation(270);
    end_barrier[31].setTexture(*end_bar_texture_p);

    //17
    end_barrier.emplace_back(End_barrier(sf::Vector2f (-58,2805)));
    end_barrier[32].setRotation(135);
    end_barrier[32].setTexture(*end_bar_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (-58,2805)));
    mid_barrier[32].setRotation(135);
    mid_barrier[32].setTexture(*bar_1_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (-68.6,2794.4)));
    mid_barrier[33].setRotation(135);
    mid_barrier[33].setTextureRect(sf::IntRect(0, 0, 260, 5400));
    mid_barrier[33].setTexture(*bar_6_texture_p);

    end_barrier.emplace_back(End_barrier(sf::Vector2f (-450,2412.6)));
    end_barrier[33].setRotation(315);
    end_barrier[33].setTexture(*end_bar_texture_p);

    //18
    end_barrier.emplace_back(End_barrier(sf::Vector2f (-450,2385)));
    end_barrier[34].setRotation(180);
    end_barrier[34].setTexture(*end_bar_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (-450,2385)));
    mid_barrier[34].setRotation(180);
    mid_barrier[34].setTexture(*bar_1_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (-450,2370)));
    mid_barrier[35].setRotation(180);
    mid_barrier[35].setTextureRect(sf::IntRect(0, 0, 260, 900));
    mid_barrier[35].setTexture(*bar_6_texture_p);

    end_barrier.emplace_back(End_barrier(sf::Vector2f (-450,2280)));
    end_barrier[35].setRotation(0);
    end_barrier[35].setTexture(*end_bar_texture_p);

    //19
    end_barrier.emplace_back(End_barrier(sf::Vector2f (-470,2260)));
    end_barrier[36].setRotation(135);
    end_barrier[36].setTexture(*end_bar_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (-470,2260)));
    mid_barrier[36].setRotation(135);
    mid_barrier[36].setTexture(*bar_1_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (-480.6,2249.4)));
    mid_barrier[37].setRotation(135);
    mid_barrier[37].setTextureRect(sf::IntRect(0, 0, 260, 7200));
    mid_barrier[37].setTexture(*bar_6_texture_p);

    end_barrier.emplace_back(End_barrier(sf::Vector2f (-989.7,1740.3)));
    end_barrier[37].setRotation(315);
    end_barrier[37].setTexture(*end_bar_texture_p);

    //20
    end_barrier.emplace_back(End_barrier(sf::Vector2f (-990,1710)));
    end_barrier[38].setRotation(180);
    end_barrier[38].setTexture(*end_bar_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (-990,1710)));
    mid_barrier[38].setRotation(180);
    mid_barrier[38].setTexture(*bar_1_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (-990,1695)));
    mid_barrier[39].setRotation(180);
    mid_barrier[39].setTextureRect(sf::IntRect(0, 0, 260, 7460));
    mid_barrier[39].setTexture(*bar_6_texture_p);

    end_barrier.emplace_back(End_barrier(sf::Vector2f (-990,950)));
    end_barrier[39].setRotation(0);
    end_barrier[39].setTexture(*end_bar_texture_p);

    //21
    end_barrier.emplace_back(End_barrier(sf::Vector2f (-960,950)));
    end_barrier[40].setRotation(270);
    end_barrier[40].setTexture(*end_bar_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (-960,950)));
    mid_barrier[40].setRotation(270);
    mid_barrier[40].setTexture(*bar_1_texture_p);

    mid_barrier.emplace_back(Middle_barrier(sf::Vector2f (-945,950)));
    mid_barrier[41].setRotation(270);
    mid_barrier[41].setTextureRect(sf::IntRect(0, 0, 260, 7500));
    mid_barrier[41].setTexture(*bar_6_texture_p);

    end_barrier.emplace_back(End_barrier(sf::Vector2f (-195,950)));
    end_barrier[41].setRotation(90);
    end_barrier[41].setTexture(*end_bar_texture_p);


}


//____COLLISION____
double get_a(double &x1, double &y1, double &x2, double &y2){
    return ((y1-y2)/(x1-x2));
}
double get_b(double &x1, double &y1, double &x2, double &y2){
    return (((y1*x2)-(y2*x1))/(x2-x1));
}
bool touch_90(double &x, double &y, double &left, double &right, double &up, double &down ){
    bool RET=false;
    if(x<right && x>left && y>up && y<down){
        RET=true;
    }
    return RET;
}
bool touch_45(double &x, double &y, double &aAB, double &bAB, double &aBC, double &bBC, double &aCD, double bCD, double &aDA, double &bDA){
    bool RET=false;
    double yAB, yBC, yCD, yDA;

    yAB=(aAB*x)+bAB;
    yBC=(aBC*x)+bBC;
    yCD=(aCD*x)+bCD;
    yDA=(aDA*x)+bDA;

    if(y>yAB){if(y>yDA){if(y<yBC){if(y<yCD){RET=true;}}}}

    return RET;
}
bool collision(sf::Sprite &object1, sf::Sprite &object2){

    bool hit=false;

    double left[3], right[3], up[3], down[3];
    double Ax[3], Bx[3], Cx[3], Dx[3];
    double Ay[3], By[3], Cy[3], Dy[3];
    double a[3][5], b[3][5];
    float angle[3];
    double high[3], width[3];
    double pi=3.14159265359;
    int compare_angle;
    double compare_angle1;

    compare_angle=object1.getRotation();
    object1.setRotation(0);
    sf::FloatRect object1_bounds = object1.getGlobalBounds();
    high[1]=object1_bounds.height;
    width[1]=object1_bounds.width;
    object1.setRotation(compare_angle);

    compare_angle1=object2.getRotation();
    object2.setRotation(0);
    sf::FloatRect object2_bounds = object2.getGlobalBounds();
    high[2]=object1_bounds.height;
    width[2]=object1_bounds.width;
    object2.setRotation(compare_angle1);

    object1_bounds = object1.getGlobalBounds();
    object2_bounds = object2.getGlobalBounds();

    left[1]=object1_bounds.left;
    right[1]=object1_bounds.left+object1_bounds.width;
    up[1]=object1_bounds.top;
    down[1]=object1_bounds.top+object1_bounds.height;
    angle[1]=object1.getRotation();

    left[2]=object2_bounds.left;
    right[2]=object2_bounds.left+object2_bounds.width;
    up[2]=object2_bounds.top;
    down[2]=object2_bounds.top+object2_bounds.height;
    angle[2]=object2.getRotation();



    for(int i=1; i<3; i++){
        //std::cout<<i<<" ";
        if(angle[i]>180){angle[i]=angle[i]-180;}
        if(angle[i]<90.0){
            Ay[i]=up[i];
            Ax[i]=left[i]+(sin(angle[i]*pi/180)*high[i]);

            Cy[i]=down[i];
            Cx[i]=right[i]-(sin(angle[i]*pi/180)*high[i]);

            By[i]=up[i]+(sin(angle[i]*pi/180)*width[i]);
            Bx[i]=right[i];

            Dy[i]=down[i]-(sin(angle[i]*pi/180)*width[i]);
            Dx[i]=left[i];
            //std::cout<<"A("<<Ax[i]<<","<<Ay[i]<<") B("<<Bx[i]<<","<<By[i]<<") C("<<Cx[i]<<","<<Cy[i]<<") D("<<Dx[i]<<","<<Dy[i]<<")"<<std::endl;
        }else{
            angle[i]=angle[i]-90.0;

            Ay[i]=up[i];
            Ax[i]=left[i]+(sin(angle[i]*pi/180)*width[i]);

            Cy[i]=down[i];
            Cx[i]=right[i]-(sin(angle[i]*pi/180)*width[i]);

            By[i]=up[i]+(sin((angle[i])*pi/180)*high[i]);
            Bx[i]=right[i];

            Dy[i]=down[i]-(sin(angle[i]*pi/180)*high[i]);
            Dx[i]=left[i];
            //std::cout<<"A("<<Ax[i]<<","<<Ay[i]<<") B("<<Bx[i]<<","<<By[i]<<") C("<<Cx[i]<<","<<Cy[i]<<") D("<<Dx[i]<<","<<Dy[i]<<")"<<std::endl;
        }

        a[i][1]=get_a(Ax[i],Ay[i],Bx[i],By[i]);
        a[i][2]=get_a(Bx[i],By[i],Cx[i],Cy[i]);
        a[i][3]=get_a(Cx[i],Cy[i],Dx[i],Dy[i]);
        a[i][4]=get_a(Dx[i],Dy[i],Ax[i],Ay[i]);
        b[i][1]=get_b(Ax[i],Ay[i],Bx[i],By[i]);
        b[i][2]=get_b(Bx[i],By[i],Cx[i],Cy[i]);
        b[i][3]=get_b(Cx[i],Cy[i],Dx[i],Dy[i]);
        b[i][4]=get_b(Dx[i],Dy[i],Ax[i],Ay[i]);

        //std::cout<<"a_AB "<<a[i][1]<<" "<<"a_BC "<<a[i][2]<<" "<<"a_CD "<<a[i][3]<<" "<<"a_DA "<<a[i][4]<<std::endl;
        //std::cout<<"b_AB "<<b[i][1]<<" "<<"b_BC "<<b[i][2]<<" "<<"b_CD "<<b[i][3]<<" "<<"b_DA "<<b[i][4]<<std::endl<<std::endl;
    }

    compare_angle=angle[1];
    //std::cout<<compare_angle<<" \n";
    if((compare_angle%90)==0){
        if(touch_90(Ax[2],Ay[2],left[1],right[1],up[1],down[1])==true ||
           touch_90(Bx[2],By[2],left[1],right[1],up[1],down[1])==true ||
           touch_90(Cx[2],Cy[2],left[1],right[1],up[1],down[1])==true ||
           touch_90(Dx[2],Dy[2],left[1],right[1],up[1],down[1])==true ){
            hit=true;
        }
    }else{
        if(touch_45(Ax[2],Ay[2],a[1][1],b[1][1],a[1][2],b[1][2],a[1][3],b[1][3],a[1][4],b[1][4])==true ||
           touch_45(Bx[2],By[2],a[1][1],b[1][1],a[1][2],b[1][2],a[1][3],b[1][3],a[1][4],b[1][4])==true ||
           touch_45(Cx[2],Cy[2],a[1][1],b[1][1],a[1][2],b[1][2],a[1][3],b[1][3],a[1][4],b[1][4])==true ||
           touch_45(Dx[2],Dy[2],a[1][1],b[1][1],a[1][2],b[1][2],a[1][3],b[1][3],a[1][4],b[1][4])==true ){
            hit=true;
        }
    }

    compare_angle=angle[2];
    //std::cout<<compare_angle<<" \n";
    if((compare_angle%90)==0){
        if(touch_90(Ax[1],Ay[1],left[2],right[2],up[2],down[2])==true ||
           touch_90(Bx[1],By[1],left[2],right[2],up[2],down[2])==true ||
           touch_90(Cx[1],Cy[1],left[2],right[2],up[2],down[2])==true ||
           touch_90(Dx[1],Dy[1],left[2],right[2],up[2],down[2])==true ){
            hit=true;
        }
    }else{
        if(touch_45(Ax[1],Ay[1],a[2][1],b[2][1],a[2][2],b[2][2],a[2][3],b[2][3],a[2][4],b[2][4])==true ||
           touch_45(Bx[1],By[1],a[2][1],b[2][1],a[2][2],b[2][2],a[2][3],b[2][3],a[2][4],b[2][4])==true ||
           touch_45(Cx[1],Cy[1],a[2][1],b[2][1],a[2][2],b[2][2],a[2][3],b[2][3],a[2][4],b[2][4])==true ||
           touch_45(Dx[1],Dy[1],a[2][1],b[2][1],a[2][2],b[2][2],a[2][3],b[2][3],a[2][4],b[2][4])==true ){
            hit=true;
        }

    }

    //std::cout<<std::endl;
    return hit;
}

bool car_collision(Middle_barrier &object1, Car &car){

    bool hit=false;

    double left[3], right[3], up[3], down[3];
    double Ax[3], Bx[3], Cx[3], Dx[3];
    double Ay[3], By[3], Cy[3], Dy[3];
    double a[3][5], b[3][5];
    float angle[3];
    double high[3], width[3];
    double pi=3.14159265359;
    int compare_angle;

    compare_angle=object1.getRotation();
    object1.setRotation(0);
    sf::FloatRect object1_bounds = object1.getGlobalBounds();
    high[1]=object1_bounds.height;
    width[1]=object1_bounds.width;
    object1.setRotation(compare_angle);

    sf::FloatRect object2_bounds;
    //high[2]=object1_bounds.height;
    //width[2]=object1_bounds.width;
    car.car_size(high[2],width[2]);

    object1_bounds = object1.getGlobalBounds();
    object2_bounds = car.getGlobalBounds();

    left[1]=object1_bounds.left;
    right[1]=object1_bounds.left+object1_bounds.width;
    up[1]=object1_bounds.top;
    down[1]=object1_bounds.top+object1_bounds.height;
    angle[1]=object1.getRotation();

    left[2]=object2_bounds.left;
    right[2]=object2_bounds.left+object2_bounds.width;
    up[2]=object2_bounds.top;
    down[2]=object2_bounds.top+object2_bounds.height;
    angle[2]=car.getRotation();



    for(int i=1; i<3; i++){
        //std::cout<<i<<" ";
        if(angle[i]>180){angle[i]=angle[i]-180;}
        if(angle[i]<90.0){
            Ay[i]=up[i];
            Ax[i]=left[i]+(sin(angle[i]*pi/180)*high[i]);

            Cy[i]=down[i];
            Cx[i]=right[i]-(sin(angle[i]*pi/180)*high[i]);

            By[i]=up[i]+(sin(angle[i]*pi/180)*width[i]);
            Bx[i]=right[i];

            Dy[i]=down[i]-(sin(angle[i]*pi/180)*width[i]);
            Dx[i]=left[i];
            //std::cout<<"A("<<Ax[i]<<","<<Ay[i]<<") B("<<Bx[i]<<","<<By[i]<<") C("<<Cx[i]<<","<<Cy[i]<<") D("<<Dx[i]<<","<<Dy[i]<<")"<<std::endl;
        }else{
            angle[i]=angle[i]-90.0;

            Ay[i]=up[i];
            Ax[i]=left[i]+(sin(angle[i]*pi/180)*width[i]);

            Cy[i]=down[i];
            Cx[i]=right[i]-(sin(angle[i]*pi/180)*width[i]);

            By[i]=up[i]+(sin((angle[i])*pi/180)*high[i]);
            Bx[i]=right[i];

            Dy[i]=down[i]-(sin(angle[i]*pi/180)*high[i]);
            Dx[i]=left[i];
            //std::cout<<"A("<<Ax[i]<<","<<Ay[i]<<") B("<<Bx[i]<<","<<By[i]<<") C("<<Cx[i]<<","<<Cy[i]<<") D("<<Dx[i]<<","<<Dy[i]<<")"<<std::endl;
        }

        a[i][1]=get_a(Ax[i],Ay[i],Bx[i],By[i]);
        a[i][2]=get_a(Bx[i],By[i],Cx[i],Cy[i]);
        a[i][3]=get_a(Cx[i],Cy[i],Dx[i],Dy[i]);
        a[i][4]=get_a(Dx[i],Dy[i],Ax[i],Ay[i]);
        b[i][1]=get_b(Ax[i],Ay[i],Bx[i],By[i]);
        b[i][2]=get_b(Bx[i],By[i],Cx[i],Cy[i]);
        b[i][3]=get_b(Cx[i],Cy[i],Dx[i],Dy[i]);
        b[i][4]=get_b(Dx[i],Dy[i],Ax[i],Ay[i]);

        //std::cout<<"a_AB "<<a[i][1]<<" "<<"a_BC "<<a[i][2]<<" "<<"a_CD "<<a[i][3]<<" "<<"a_DA "<<a[i][4]<<std::endl;
        //std::cout<<"b_AB "<<b[i][1]<<" "<<"b_BC "<<b[i][2]<<" "<<"b_CD "<<b[i][3]<<" "<<"b_DA "<<b[i][4]<<std::endl<<std::endl;
    }

    compare_angle=angle[1];
    //std::cout<<compare_angle<<" \n";
    if((compare_angle%90)==0){
        if(touch_90(Ax[2],Ay[2],left[1],right[1],up[1],down[1])==true ||
           touch_90(Bx[2],By[2],left[1],right[1],up[1],down[1])==true ||
           touch_90(Cx[2],Cy[2],left[1],right[1],up[1],down[1])==true ||
           touch_90(Dx[2],Dy[2],left[1],right[1],up[1],down[1])==true ){
            hit=true;
        }
    }else{
        if(touch_45(Ax[2],Ay[2],a[1][1],b[1][1],a[1][2],b[1][2],a[1][3],b[1][3],a[1][4],b[1][4])==true ||
           touch_45(Bx[2],By[2],a[1][1],b[1][1],a[1][2],b[1][2],a[1][3],b[1][3],a[1][4],b[1][4])==true ||
           touch_45(Cx[2],Cy[2],a[1][1],b[1][1],a[1][2],b[1][2],a[1][3],b[1][3],a[1][4],b[1][4])==true ||
           touch_45(Dx[2],Dy[2],a[1][1],b[1][1],a[1][2],b[1][2],a[1][3],b[1][3],a[1][4],b[1][4])==true ){
            hit=true;
        }
    }

    compare_angle=angle[2];
    //std::cout<<compare_angle<<" \n";
    if((compare_angle%90)==0){
        if(touch_90(Ax[1],Ay[1],left[2],right[2],up[2],down[2])==true ||
           touch_90(Bx[1],By[1],left[2],right[2],up[2],down[2])==true ||
           touch_90(Cx[1],Cy[1],left[2],right[2],up[2],down[2])==true ||
           touch_90(Dx[1],Dy[1],left[2],right[2],up[2],down[2])==true ){
            hit=true;
        }
    }else{
        if(touch_45(Ax[1],Ay[1],a[2][1],b[2][1],a[2][2],b[2][2],a[2][3],b[2][3],a[2][4],b[2][4])==true ||
           touch_45(Bx[1],By[1],a[2][1],b[2][1],a[2][2],b[2][2],a[2][3],b[2][3],a[2][4],b[2][4])==true ||
           touch_45(Cx[1],Cy[1],a[2][1],b[2][1],a[2][2],b[2][2],a[2][3],b[2][3],a[2][4],b[2][4])==true ||
           touch_45(Dx[1],Dy[1],a[2][1],b[2][1],a[2][2],b[2][2],a[2][3],b[2][3],a[2][4],b[2][4])==true ){
            hit=true;
        }

    }

    //std::cout<<std::endl;
    return hit;
}


#endif // FUNCTIONS_H
